//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2024) Chaahat Jain.
//

#include "prob_fault_finding.h"
#include "../../../../exception/plaja_exception.h"
#include "../../../../globals.h"
#include "../../../../parser/ast/expression/non_standard/objective_expression.h"
#include "../../../../parser/ast/model.h"
#include "../../../factories/configuration.h"
#include "../../../fd_adaptions/state.h"
#include "../../../fd_adaptions/timer.h"
#include "../../../information/jani_2_interface.h"
#include "../../../information/model_information.h"
#include "../../../information/property_information.h"
#include "../../../non_prob_search/initial_states_enumerator.h"
#include "../../../successor_generation/simulation_environment.h"
// #include "ATen/core/interned_strings.h"
#include <cmath>
#include "../../../factories/fault_analysis/fault_analysis_options.h"
#ifdef BUILD_PA
#include "../../../factories/predicate_abstraction/search_engine_config_pa.h"
#endif

#include "../../../../option_parser/option_parser.h"
#include "../../../../option_parser/option_parser_aux.h"

#include "../../../successor_generation/base/successor_distribution.h"

#include <numeric>
#include <iostream>
#include <fstream>
#include <vector>
#include <json.hpp>
using json = nlohmann::json;

// one_way_line non_det_no_park, it0 ensemble policy (pi-unsafe everywhere: no safe absorbing states, so P(eventually crash) = 1 from every state):
// ./PlaJA --engine FAULT_ANALYSIS --model-file ../../PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/jani_models_and_teachers/one_way_line/models/non_det_no_park/one_way_line.jani --seed 10 --max-time 60 --ensemble-interface /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/jani_models_and_teachers//one_way_line/networks/non_det_no_park/one_way_line/one_way_line_crazy_long.jani2nnet --ensemble /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/ensembles/one_way_line/one_way_line_crazy_long_non_det_no_park_5depth_20trees_0.4LR_it0.json --initial-state-enum sample --additional-properties /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/jani_models_and_teachers/one_way_line/additional_properties/safety_verification/non_det_no_park/compact_starts_no_predicates/one_way_line/pa_one_way_line_compact_starts_no_predicates.jani --prop 1 --oracle-use prob_finding --num-starts 1 --distance-func avoid --applicability-filtering 1
//
// one_way_line non_det_with_park, neural teacher policy (still pi-unsafe everywhere: exact mass is 1 on all sampled states, teacher never parks):
// ./PlaJA --engine FAULT_ANALYSIS --model-file ../../PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/jani_models_and_teachers/one_way_line/models/non_det_with_park/one_way_line.jani --seed 10 --max-time 300 --nn-interface /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/jani_models_and_teachers/one_way_line/networks/non_det_with_park/one_way_line/one_way_line_32_32.jani2nnet --nn /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/jani_models_and_teachers/one_way_line/networks/non_det_with_park/one_way_line/one_way_line_32_32.nnet --initial-state-enum sample --additional-properties /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/icaps26_fault_fixing/jani_models_and_teachers/one_way_line/additional_properties/safety_verification/non_det_with_park/compact_starts_no_predicates/one_way_line/pa_one_way_line_compact_starts_no_predicates.jani --prop 1 --oracle-use prob_finding --num-starts 20 --distance-func avoid --applicability-filtering 1 --prob-fuzzing-algorithm vi
//
// blocksworld_4_3, safe neural teacher (learned_no_cost; exact mass is 0 on all sampled states -> produces pi-safe verdicts; fp 0.95 keeps the safe side fast):
// ./PlaJA --engine FAULT_ANALYSIS --model-file /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/ecai24/blocksworld/models/cost05/blocksworld_4_3.jani --seed 10 --max-time 300 --nn-interface /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/ecai24/blocksworld/networks/blocksworld_4_3/learned_no_cost/blocksworld_4_3_16_16/blocksworld_4_3_16_16.jani2nnet --nn /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/ecai24/blocksworld/networks/blocksworld_4_3/learned_no_cost/blocksworld_4_3_16_16/blocksworld_4_3_16_16.nnet --initial-state-enum sample --additional-properties /home/chaahat/Desktop/PhD_projects/code/PlaJABenchmarks/benchmarks_archive/ecai24/blocksworld/additional_properties/safety_verification/cost05/blocksworld_4_3/compact_starts_no_predicates/learned_no_cost/pa_compact_starts_no_predicates_blocksworld_4_3_16_16_0.jani --prop 1 --oracle-use prob_finding --num-starts 20 --distance-func avoid --applicability-filtering 1 --prob-fuzzing-algorithm brtdp --failure-probability 0.95

namespace PLAJA_OPTION_DEFAULT {
    const std::string prob_fuzzing_algorithm("dfs"); // NOLINT(cert-err58-cpp)
    const double failure_probability(0.05); // NOLINT(cert-err58-cpp)
} // namespace PLAJA_OPTION_DEFAULT


namespace PLAJA_OPTION {
    const std::string prob_fuzzing_algorithm("prob-fuzzing-algorithm"); // NOLINT(cert-err58-cpp)
    const std::string failure_probability("failure-probability"); // NOLINT(cert-err58-cpp)

    namespace PROB_FA_ENGINE {
        void add_options(PLAJA::OptionParser& option_parser) {
            OPTION_PARSER::add_option(option_parser, prob_fuzzing_algorithm, PLAJA_OPTION_DEFAULT::prob_fuzzing_algorithm);
            OPTION_PARSER::add_double_option(option_parser, failure_probability, PLAJA_OPTION_DEFAULT::failure_probability);
        }

        extern void print_options() {
            OPTION_PARSER::print_option(PLAJA_OPTION::prob_fuzzing_algorithm, "<option>", "Which fuzzing algorithm to use to find states to run fault analysis on?", true);
            OPTION_PARSER::print_additional_specification(PLAJA::OptionParser::print_supported_options(stringToFuzzing), true);
            OPTION_PARSER::print_double_option(PLAJA_OPTION::failure_probability, PLAJA_OPTION_DEFAULT::failure_probability, "Probability of failure decided by the user to determine when the policy is unsafe.");
        }
    } // namespace PROB_FA_ENGINE
} // namespace PLAJA_OPTION

ProbFaultFinding::ProbFaultFinding(const PLAJA::Configuration& config):
    FaultEngine(config),
    paths_to_sample(config.get_int_option(PLAJA_OPTION::num_paths_per_start))
{
    /* The pi-safety check algorithm. */
    fuzzer = ProbFuzzer::create(
        config.get_option(PLAJA_OPTION::PROB_FA_ENGINE::stringToFuzzing, PLAJA_OPTION::prob_fuzzing_algorithm),
        config.get_double_option(PLAJA_OPTION::failure_probability),
        config.get_double_option(PLAJA_OPTION::fuzz_time_limit),
        simulatorEnv, policy, avoid, searchStatistics);

    /* Start State Sampling */
    std::unordered_set<StateID_type> start_states;
    if (startEnumerator) {
        startEnumerator->initialize();
        bool fixed_start_states = not startEnumerator->samples();
        if (fixed_start_states) {
            /* Enumerate and store states */
            for (const auto& start_state: startEnumerator->enumerate_states()) {
                const auto start_id = simulatorEnv->get_state(start_state).get_id_value();
                if (start_states.insert(start_id).second) {
                    startStates.push_back(start_id);
                    searchStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::START_STATES);
                }
            }
        } else {
            PLAJA_ASSERT(propertyInfo->get_start())
            startStates.clear();
            while (startStates.size() < numEpisodes) {
                auto start_sample = startEnumerator->sample_state();
                const auto start_state_id = simulatorEnv->get_state(*start_sample).get_id_value();
                startStates.push_back(start_state_id);
                searchStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::START_STATES);
            }
            startEnumerator = nullptr;
        }

        if (specified_start_state_index >= 0) {
            // If we run fault analysis from a single start state, then run the entire check exactly once.
            PLAJA_ASSERT(specified_start_state_index < static_cast<int>(startStates.size()))
            startStates = {startStates[specified_start_state_index]};
            numEpisodes = 1;
            PLAJA_LOG("Using fixed start state index " + std::to_string(specified_start_state_index) + " with state id " + std::to_string(startStates[0]))
        } else {
            // Used to split the start state set into training and testing sets.
            size_t splitIndex = static_cast<size_t>(train_test_split * startStates.size());
            if (evaluation_mode) {
                // Keep only the evaluation part
                startStates.assign(startStates.begin() + splitIndex, startStates.end());
            } else {
                // Keep only the training part
                startStates.assign(startStates.begin(), startStates.begin() + splitIndex);
            }
            numEpisodes = std::min<size_t>(startStates.size(), numEpisodes);
        }
    }
}

ProbFaultFinding::~ProbFaultFinding() = default;

State ProbFaultFinding::sample_start_state() {
    const StateID_type start_id = startStates[episodesCounter % startStates.size()]; // When using a fixed start state set
    return simulatorEnv->get_state(start_id);
}

SearchEngine::SearchStatus ProbFaultFinding::step() {
    if (episodesCounter >= numEpisodes) {
        return SearchStatus::SOLVED;
    }

    searchStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::EPISODES);

    // sample start state until choice point
    std::unique_ptr<State> current_state = sample_start_state().to_ptr();
    // std::cout << "Episodes counter is at: " << episodesCounter << "and numEpisodes at" << numEpisodes << " with new start state: "; current_state->dump();
    searchStatistics->set_attr_string(PLAJA::StatsString::STATES_FOR_ORACLE, "");
    if (not current_state) { // drawn start state leads to "done" without any decision
        static bool print_warning(true);
        PLAJA_LOG_IF(print_warning, PLAJA_UTILS::to_red_string("Terminal start state."))
        ++episodesCounter;
        print_warning = false;
        return SearchStatus::IN_PROGRESS;
    } else { // found choice point -> count step as episode
        ++episodesCounter;
        searchStatistics->set_attr_string(PLAJA::StatsString::START_STATE_CHECKED, current_state->save_as_str());
    }

    PLAJA_ASSERT(evaluation_metric == FaultEngine::PolicyEvaluationMetric::SAMPLE_PI_PATHS)
    /* Sample policy runs to compute policy performance. */
    auto state_id = current_state->get_id_value();
    for (int i = 0; i < paths_to_sample; ++i) {
        searchStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::PATHS_CHECKED, 1);
        auto path_ps = policy_run_sampler->sample_path(state_id);
        // Fuzz every state on the sampled trace, not only those on unsafe traces:
        // unsafe traces localize the fault frontier, while safe traces let us
        // evaluate the pi-safe side of the fuzzing verdicts as well.
        const bool unsafe_trace = path_ps.second.avoid_count > 0;
        for (auto s_id: path_ps.first.states) {
            searchStatistics->set_attr_string(PLAJA::StatsString::STATES_FOR_ORACLE, simulatorEnv->get_state(s_id).save_as_str());
            Timer::Time_type fuzz_elapsed = 0.0;
            PUSH_LAP(searchStatistics, PLAJA::StatsDouble::FUZZ_TIME);
            bool is_pi_safe = fuzzer->is_state_pi_safe(s_id);
            POP_LAP_AND_CACHE(searchStatistics, PLAJA::StatsDouble::FUZZ_TIME, fuzz_elapsed);
            searchStatistics->set_attr_unsigned(PLAJA::StatsUnsigned::FUZZ_RESULT_PI_SAFE, is_pi_safe ? 1 : 0);
            std::cout << "[FUZZ] " << (is_pi_safe ? "pi-safe" : "pi-unsafe")
                      << " in " << fuzz_elapsed << "s | trace: " << (unsafe_trace ? "unsafe" : "safe")
                      << " | " << fuzzer->last_verdict_details()
                      << " | state: ";
            simulatorEnv->get_state(s_id).dump();
            trigger_intermediate_stats();
        }
    }

    // trigger_intermediate_stats();
    return SearchStatus::IN_PROGRESS;
}
