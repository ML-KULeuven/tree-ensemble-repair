//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

// Depth-first enumeration of policy trajectories, accumulating the exact
// probability mass mu of paths that reach an avoid state. Paths below
// path_epsilon are discarded and optimistically counted as safe.
// Early termination in both directions:
//   * mu >= fail_prob                      -> UNSAFE
//   * mu + frontier mass < fail_prob       -> SAFE (upper bound)

#ifndef PLAJA_DFS_FUZZER_H
#define PLAJA_DFS_FUZZER_H

#include "prob_fuzzer.h"

class DfsFuzzer final : public ProbFuzzer {
public:
    using ProbFuzzer::ProbFuzzer;

    bool is_state_pi_safe(StateID_type state) override;
    [[nodiscard]] std::string name() const override { return "DFS"; }
};

#endif //PLAJA_DFS_FUZZER_H
