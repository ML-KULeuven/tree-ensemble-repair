//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

#include "dfs_fuzzer.h"

#include <sstream>

bool DfsFuzzer::is_state_pi_safe(StateID_type state_id) {

    using Path = std::vector<StateID_type>;

    struct FrontierEntry {
        StateID_type state_id;
        Path         path;
        PLAJA::Prob_type prob;
    };

    PLAJA::Prob_type mu = 0.0;
    PLAJA::Prob_type discarded = 0.0;
    PLAJA::Prob_type frontier_mass = 1.0; // Total probability mass currently sitting in the frontier.
    std::vector<FrontierEntry> frontier;
    frontier.reserve(64);

    frontier.push_back({state_id, Path{state_id}, 1.0});

    fuzzDeadline.restart(); // Fresh wall-clock budget for this pi-safety check.

    while (!frontier.empty()) {
        if (fuzzDeadline.expired()) { // Time limit hit: abandon and conservatively report SAFE (inconclusive).
            return report_timeout();
        }
        // Early SAFE termination: mu + frontier_mass is an upper bound on the
        // unsafety mass this search can still accumulate (frontier mass is
        // conservatively counted as unsafe; discarded mass counts as safe).
        // Once even that bound is below the threshold, the state is pi-safe.
        if (mu + frontier_mass < fail_prob) {
            std::ostringstream details;
            details << "mass<=" << (mu + frontier_mass) << " | discarded(safe)=" << discarded;
            verdictDetails = details.str();
            return true;
        }
        FrontierEntry cur = std::move(frontier.back());
        frontier.pop_back();
        frontier_mass -= cur.prob;
        if (cur.prob < path_epsilon) {
            discarded += cur.prob; // Counted as safe; tracked for diagnostics only.
            continue; // Path has very little probability to play a significant role here at all.
        }

        // s' in S_f ?
        if (is_avoid_state(cur.state_id)) {
            mu += cur.prob;
            if (mu >= fail_prob) {
                std::ostringstream details;
                details << "mass>=" << mu;
                verdictDetails = details.str();
                return false;
            }
            continue;
        }

        // Expand: a = pi(s'), then iterate over successors
        for (const auto& [succ_id, trans_prob] : successors(cur.state_id)) {
            Path new_path = cur.path; // copy: paths must diverge per branch
            new_path.push_back(succ_id);

            frontier.push_back({succ_id, std::move(new_path), cur.prob * trans_prob});
            frontier_mass += cur.prob * trans_prob;
        }
    }
    std::ostringstream details;
    details << "mass=" << mu << " | discarded(safe)=" << discarded;
    verdictDetails = details.str();
    return mu < fail_prob;
}
