//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2024) Chaahat Jain.
//

// Intuition: Keep track of states explored by policy. If we find unsafe state, then backtrack and try sub-optimal actions. If we reach safety, then we detected a fault.

#ifndef PLAJA_PROB_FAULT_FINDING_H
#define PLAJA_PROB_FAULT_FINDING_H

#include <vector>
#include <unordered_set>
#include "../../../../parser/ast/expression/forward_expression.h"
#include "../fault_engine.h"
#include "../deadline.h"
#include "../../../information/jani_2_interface.h"
#include "../../../states/forward_states.h"
#include "../../../successor_generation/forward_successor_generation.h"
#include "../../../using_search.h"
#include "../../../non_prob_search/policy/policy_restriction.h"
#include <stack>
#include "../oracle.h"
#include "../search_statistics_fault.h"
#include "../../../../search/smt/model/model_z3.h"
#include "../../../../search/smt/bias_functions/distance_function.h"
#ifdef BUILD_PA
#include "../../../predicate_abstraction/cegar/pa_cegar.h"
#endif
#include "../../../information/property_information.h"

#include "prob_fuzzing/prob_fuzzer.h"


class ProbFaultFinding: public FaultEngine {
private:
    int paths_to_sample = 1;
    std::unique_ptr<ProbFuzzer> fuzzer; // The pi-safety check algorithm (dfs/vi/mcts/brtdp).

    SearchStatus step() override;
    State sample_start_state();

public:
    explicit ProbFaultFinding(const PLAJA::Configuration& config);
    ~ProbFaultFinding() override;
    DELETE_CONSTRUCTOR(ProbFaultFinding)

};


namespace PLAJA_OPTION {
    extern const std::string prob_fuzzing_algorithm;
    extern const std::string failure_probability;
    namespace PROB_FA_ENGINE {
        const std::unordered_map<std::string, ProbFuzzer::Algorithm> stringToFuzzing {
            {"vi", ProbFuzzer::Algorithm::VI},
            {"dfs", ProbFuzzer::Algorithm::DFS},
            {"mcts", ProbFuzzer::Algorithm::MCTS},
            {"brtdp", ProbFuzzer::Algorithm::BRTDP},
        };
        extern void add_options(PLAJA::OptionParser& option_parser);
        extern void print_options();
    } // namespace PROB_FA_ENGINE

}// namespace PLAJA_OPTION

#endif //PLAJA_PROB_FAULT_FINDING_H
