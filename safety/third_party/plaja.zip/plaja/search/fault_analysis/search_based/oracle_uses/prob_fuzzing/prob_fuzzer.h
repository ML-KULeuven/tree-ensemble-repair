//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

// Generic probabilistic fuzzing interface: given a state, decide whether the
// unsafety mass reachable from it under the (fixed) policy stays below a
// user-given failure probability. Concrete algorithms (DFS, VI, MCTS, BRTDP)
// are instantiations of this class; use ProbFuzzer::create() to build one.

#ifndef PLAJA_PROB_FUZZER_H
#define PLAJA_PROB_FUZZER_H

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "../../../../using_search.h"
#include "../../../../../parser/ast/expression/forward_expression.h"
#include "../../../../successor_generation/simulation_environment.h"
#include "../../../../non_prob_search/policy/policy_restriction.h"
#include "../../../../../stats/stats_base.h"
#include "../../../../../utils/default_constructors.h"
#include "../../deadline.h"

class ProbFuzzer {
public:
    enum Algorithm {
        VI,
        DFS,
        MCTS,
        BRTDP,
    };

protected:
    std::shared_ptr<SimulationEnvironment> simulatorEnv;
    std::shared_ptr<PolicyRestriction> policy;
    const Expression* avoid;
    std::shared_ptr<PLAJA::StatsBase> searchStatistics;

    double fail_prob;      // Threshold on the unsafety mass above which a state counts as pi-unsafe.
    Deadline fuzzDeadline; // Wall-clock budget for a single pi-safety check.

    // Set by each algorithm when a verdict is reached: what is known about the
    // unsafety mass (exact value, bounds, ...). Purely diagnostic.
    std::string verdictDetails;

    // Paths below this probability are discarded by path-based algorithms
    // (DFS, MCTS) and optimistically counted as safe. (On long horizons the
    // discarded mass can be large; counting it as unsafe would make it
    // impossible to ever certify safety with a path-based method.)
    static constexpr PLAJA::Prob_type path_epsilon = 1e-4;

    /* Shared helpers. */

    // Does `state_id` satisfy the avoid condition?
    [[nodiscard]] bool is_avoid_state(StateID_type state_id) const;

    // Successor distribution of `state_id` under the policy, as
    // (successor id, transition probability) pairs; zero-probability entries
    // are filtered out. An empty result means the state is terminal.
    [[nodiscard]] std::vector<std::pair<StateID_type, PLAJA::Prob_type>> successors(StateID_type state_id) const;

    // Time limit hit: count + log it and conservatively report SAFE
    // (inconclusive); intended usage is `return report_timeout(...)`.
    bool report_timeout(const std::string& details = "") const;

public:
    ProbFuzzer(double fail_probability, double fuzz_time_limit,
               std::shared_ptr<SimulationEnvironment> env,
               std::shared_ptr<PolicyRestriction> pol,
               const Expression* avoid_expr,
               std::shared_ptr<PLAJA::StatsBase> stats);
    virtual ~ProbFuzzer();
    DELETE_CONSTRUCTOR(ProbFuzzer)

    // Is the unsafety mass reachable from `state` under the policy below
    // fail_prob? Timeouts conservatively report SAFE (inconclusive).
    virtual bool is_state_pi_safe(StateID_type state) = 0;

    // Human-readable algorithm name, used in log messages.
    [[nodiscard]] virtual std::string name() const = 0;

    // What the last is_state_pi_safe() call learned about the unsafety mass.
    [[nodiscard]] const std::string& last_verdict_details() const { return verdictDetails; }

    // Factory over all supported algorithms.
    static std::unique_ptr<ProbFuzzer> create(Algorithm algorithm,
                                              double fail_probability, double fuzz_time_limit,
                                              const std::shared_ptr<SimulationEnvironment>& env,
                                              const std::shared_ptr<PolicyRestriction>& pol,
                                              const Expression* avoid_expr,
                                              const std::shared_ptr<PLAJA::StatsBase>& stats);
};

#endif //PLAJA_PROB_FUZZER_H
