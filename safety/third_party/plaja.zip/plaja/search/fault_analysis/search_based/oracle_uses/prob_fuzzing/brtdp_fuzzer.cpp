//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

#include "brtdp_fuzzer.h"

#include "../../../../../utils/rng.h"

#include <algorithm>
#include <sstream>
#include <unordered_set>

BrtdpFuzzer::StateInfo& BrtdpFuzzer::init(StateID_type state_id) {
    auto [it, inserted] = table.try_emplace(state_id);
    if (inserted and is_avoid_state(state_id)) {
        it->second.isAvoid = true;
        it->second.lower = it->second.upper = 1.0;
    }
    return it->second;
}

BrtdpFuzzer::StateInfo& BrtdpFuzzer::expand(StateID_type state_id) {
    StateInfo& info = init(state_id);
    if (info.expanded or info.isAvoid) {
        return info; // avoid states are absorbing; never expanded
    }
    info.succs = successors(state_id);
    info.expanded = true;
    ++expansions_since_scc_pass;
    if (info.succs.empty()) {
        info.lower = info.upper = 0.0; // terminal without reaching avoid: safe
    }
    return info;
}

void BrtdpFuzzer::backup(StateID_type state_id) {
    StateInfo& info = table.at(state_id);
    if (info.isAvoid or not info.expanded or info.succs.empty()) {
        return; // bounds are fixed
    }
    PLAJA::Prob_type lower_sum = 0.0;
    PLAJA::Prob_type upper_sum = 0.0;
    for (const auto& [succ_id, trans_prob] : info.succs) {
        const StateInfo& succ = init(succ_id);
        lower_sum += trans_prob * succ.lower;
        upper_sum += trans_prob * succ.upper;
    }
    // Monotone update: bounds only ever tighten. In particular, upper bounds
    // zeroed by eliminate_safe_sccs() must not regress through looser neighbors.
    info.lower = std::max(info.lower, lower_sum);
    info.upper = std::min(info.upper, upper_sum);
}

void BrtdpFuzzer::eliminate_safe_sccs() {
    if (expansions_since_scc_pass == 0) {
        return; // explored graph unchanged since the last pass
    }
    expansions_since_scc_pass = 0;

    // Iterative Tarjan over the expanded part of the table (avoid states are
    // never expanded, so they are automatically outside the graph).
    std::unordered_map<StateID_type, int> index;
    std::unordered_map<StateID_type, int> lowlink;
    std::unordered_set<StateID_type> on_stack;
    std::vector<StateID_type> scc_stack;
    int next_index = 0;

    struct Frame {
        StateID_type id;
        std::size_t child = 0;
    };

    for (const auto& [start_id, start_info] : table) {
        if (not start_info.expanded or index.count(start_id)) continue;

        std::vector<Frame> call_stack;
        call_stack.push_back({start_id});
        index[start_id] = lowlink[start_id] = next_index++;
        scc_stack.push_back(start_id);
        on_stack.insert(start_id);

        while (not call_stack.empty()) {
            const StateID_type v = call_stack.back().id;
            const auto& v_succs = table.at(v).succs;

            if (call_stack.back().child < v_succs.size()) {
                const StateID_type w = v_succs[call_stack.back().child++].first;
                const auto w_it = table.find(w);
                if (w_it == table.end() or not w_it->second.expanded) {
                    continue; // edge leaves the explored graph; breaks SCC closedness below
                }
                if (not index.count(w)) {
                    index[w] = lowlink[w] = next_index++;
                    scc_stack.push_back(w);
                    on_stack.insert(w);
                    call_stack.push_back({w});
                } else if (on_stack.count(w)) {
                    lowlink[v] = std::min(lowlink[v], index[w]);
                }
            } else {
                if (lowlink[v] == index[v]) {
                    // Pop the SCC rooted at v.
                    std::unordered_set<StateID_type> scc;
                    StateID_type w;
                    do {
                        w = scc_stack.back();
                        scc_stack.pop_back();
                        on_stack.erase(w);
                        scc.insert(w);
                    } while (w != v);

                    // Closed iff every transition of every member stays inside
                    // the SCC (unexpanded and avoid successors are not members).
                    bool closed = true;
                    for (const auto member : scc) {
                        for (const auto& [succ_id, trans_prob] : table.at(member).succs) {
                            if (not scc.count(succ_id)) {
                                closed = false;
                                break;
                            }
                        }
                        if (not closed) break;
                    }
                    if (closed) {
                        // A closed, avoid-free SCC can never reach avoid.
                        for (const auto member : scc) {
                            table.at(member).upper = 0.0;
                        }
                    }
                }
                call_stack.pop_back();
                if (not call_stack.empty()) {
                    const StateID_type parent = call_stack.back().id;
                    lowlink[parent] = std::min(lowlink[parent], lowlink[v]);
                }
            }
        }
    }
}

bool BrtdpFuzzer::is_state_pi_safe(StateID_type state_id) {
    fuzzDeadline.restart(); // Fresh wall-clock budget for this pi-safety check.
    // Fresh state table: each check is fully independent of earlier ones.
    table.clear();
    expansions_since_scc_pass = 0;
    init(state_id);

    const auto set_details = [this, state_id]() {
        const StateInfo& root = table.at(state_id);
        std::ostringstream details;
        details << "mass in [" << root.lower << ", " << root.upper << "]";
        verdictDetails = details.str();
    };

    while (true) {
        {
            const StateInfo& root = table.at(state_id);
            if (fuzzDeadline.expired()) { // Time limit hit: abandon and conservatively report SAFE (inconclusive).
                set_details();
                return report_timeout(verdictDetails);
            }
            /* Sound termination on the exact bounds. */
            if (root.lower >= fail_prob) {
                set_details();
                return false; // proven pi-unsafe
            }
            if (root.upper < fail_prob) {
                set_details();
                return true; // proven pi-safe
            }
        }

        /* Trial: walk towards unresolved probability mass. */
        std::vector<StateID_type> trail;
        std::unordered_set<StateID_type> on_trail;
        StateID_type cur = state_id;
        bool cycled = false;

        while (not fuzzDeadline.expired()) {
            if (not on_trail.insert(cur).second) {
                cycled = true; // revisit within the trial: plain backups cannot converge this
                break;
            }
            trail.push_back(cur);

            StateInfo& info = expand(cur);
            if (info.isAvoid or info.succs.empty() or info.gap() <= 0.0) {
                break; // bounds here are settled; nothing below can change them
            }

            // Sample the successor proportional to trans_prob * gap.
            PLAJA::Prob_type total_weight = 0.0;
            for (const auto& [succ_id, trans_prob] : info.succs) {
                total_weight += trans_prob * init(succ_id).gap();
            }
            if (total_weight <= 0.0) {
                break; // all successors converged; the backup below converges cur
            }
            const double r = PLAJA_GLOBAL::rng->prob() * total_weight;
            PLAJA::Prob_type acc = 0.0;
            StateID_type next = info.succs.back().first;
            for (const auto& [succ_id, trans_prob] : info.succs) {
                acc += trans_prob * table.at(succ_id).gap();
                if (r < acc) {
                    next = succ_id;
                    break;
                }
            }
            cur = next;
        }

        /* Backup along the trail, deepest state first. */
        for (auto it = trail.rbegin(); it != trail.rend(); ++it) {
            backup(*it);
        }
        if (cycled) {
            eliminate_safe_sccs();
            // Propagate the zeroed upper bounds through the trail once more.
            for (auto it = trail.rbegin(); it != trail.rend(); ++it) {
                backup(*it);
            }
        }
    }
}
