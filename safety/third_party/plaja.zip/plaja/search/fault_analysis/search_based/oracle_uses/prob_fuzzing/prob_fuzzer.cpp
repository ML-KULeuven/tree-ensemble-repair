//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

#include "prob_fuzzer.h"

#include "dfs_fuzzer.h"
#include "vi_fuzzer.h"
#include "mcts_fuzzer.h"
#include "brtdp_fuzzer.h"

#include "../../../../../exception/plaja_exception.h"
#include "../../../../../parser/ast/expression/expression.h"
#include "../../../../fd_adaptions/state.h"
#include "../../../../successor_generation/base/successor_distribution.h"
#include "../../search_statistics_fault.h"

#include <iostream>

ProbFuzzer::ProbFuzzer(double fail_probability, double fuzz_time_limit,
                       std::shared_ptr<SimulationEnvironment> env,
                       std::shared_ptr<PolicyRestriction> pol,
                       const Expression* avoid_expr,
                       std::shared_ptr<PLAJA::StatsBase> stats):
    simulatorEnv(std::move(env)),
    policy(std::move(pol)),
    avoid(avoid_expr),
    searchStatistics(std::move(stats)),
    fail_prob(fail_probability),
    fuzzDeadline(fuzz_time_limit)
{}

ProbFuzzer::~ProbFuzzer() = default;

bool ProbFuzzer::is_avoid_state(StateID_type state_id) const {
    const State& state = simulatorEnv->get_state(state_id);
    return avoid->evaluateInteger(&state);
}

std::vector<std::pair<StateID_type, PLAJA::Prob_type>> ProbFuzzer::successors(StateID_type state_id) const {
    const State& state = simulatorEnv->get_state(state_id);
    const auto action = policy->get_action(state);
    const auto distro = simulatorEnv->compute_successor_distribution(state, action);

    std::vector<std::pair<StateID_type, PLAJA::Prob_type>> result;
    result.reserve(distro->_probDistro().size());
    for (const auto& [succ_state_ptr, trans_prob] : distro->_probDistro()) {
        if (trans_prob <= 0.0) continue;
        result.emplace_back(succ_state_ptr->get_id(), trans_prob);
    }
    return result;
}

bool ProbFuzzer::report_timeout(const std::string& details) const {
    searchStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::FUZZ_TIMEOUT);
    std::cout << "[FUZZ] " << name() << " timed out after " << fuzzDeadline.limit_seconds()
              << "s -> reporting SAFE (inconclusive)"
              << (details.empty() ? "" : " | " + details) << "." << std::endl;
    return true;
}

std::unique_ptr<ProbFuzzer> ProbFuzzer::create(Algorithm algorithm,
                                               double fail_probability, double fuzz_time_limit,
                                               const std::shared_ptr<SimulationEnvironment>& env,
                                               const std::shared_ptr<PolicyRestriction>& pol,
                                               const Expression* avoid_expr,
                                               const std::shared_ptr<PLAJA::StatsBase>& stats) {
    switch (algorithm) {
        case Algorithm::DFS:
            return std::make_unique<DfsFuzzer>(fail_probability, fuzz_time_limit, env, pol, avoid_expr, stats);
        case Algorithm::VI:
            return std::make_unique<ViFuzzer>(fail_probability, fuzz_time_limit, env, pol, avoid_expr, stats);
        case Algorithm::MCTS:
            return std::make_unique<MctsFuzzer>(fail_probability, fuzz_time_limit, env, pol, avoid_expr, stats);
        case Algorithm::BRTDP:
            return std::make_unique<BrtdpFuzzer>(fail_probability, fuzz_time_limit, env, pol, avoid_expr, stats);
    }
    PLAJA_ABORT;
}
