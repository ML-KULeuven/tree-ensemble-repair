//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

#include "mcts_fuzzer.h"

#include "../../../../../exception/plaja_exception.h"
#include "../../../../../utils/rng.h"

#include <cmath>
#include <iostream>
#include <sstream>

double MctsFuzzer::rollout(StateID_type from_id) const {
    StateID_type cur = from_id;
    for (int depth = 0; depth < rollout_depth; ++depth) {
        if (is_avoid_state(cur)) {
            return 1.0;
        }
        const auto succs = successors(cur);
        if (succs.empty()) {
            return 0.0; // terminal state: safe
        }
        const double r = PLAJA_GLOBAL::rng->prob();
        PLAJA::Prob_type acc = 0.0;
        bool chosen = false;
        for (const auto& [succ_id, trans_prob] : succs) {
            acc += trans_prob;
            if (r < acc) {
                cur = succ_id;
                chosen = true;
                break;
            }
        }
        if (not chosen) {
            return 0.0; // lost mass of a sub-stochastic distribution: safe termination
        }
    }
    return 0.0; // depth limit hit: counts as safe; only affects guidance, not the verdict
}

bool MctsFuzzer::is_state_pi_safe(StateID_type state_id) {

    struct MctsNode {
        StateID_type state_id;
        PLAJA::Prob_type path_prob;   // P(reaching this node from the root along its path)
        PLAJA::Prob_type lower = 0.0; // exact bounds on P(reach avoid | at this node)
        PLAJA::Prob_type upper = 1.0;
        double q = 0.0;               // mean rollout reward, estimate of P(reach avoid)
        unsigned visits = 0;
        int parent = -1;
        bool expanded = false;
        std::vector<std::pair<int, PLAJA::Prob_type>> children; // (node index, transition probability)
    };

    std::vector<MctsNode> nodes;
    nodes.reserve(1024);

    // A node is worth further exploration iff its bounds have a gap that can
    // still be closed.
    auto refinable = [&nodes](int idx) {
        const MctsNode& n = nodes[idx];
        return (n.upper - n.lower) > 0.0;
    };

    /* Root node. */
    {
        MctsNode root;
        root.state_id = state_id;
        root.path_prob = 1.0;
        if (is_avoid_state(state_id)) {
            root.lower = root.upper = 1.0;
        }
        nodes.push_back(std::move(root));
    }

    fuzzDeadline.restart(); // Fresh wall-clock budget for this pi-safety check.

    const auto set_details = [this, &nodes]() {
        std::ostringstream details;
        details << "mass in [" << nodes[0].lower << ", " << nodes[0].upper << "]";
        verdictDetails = details.str();
    };

    while (true) {
        if (fuzzDeadline.expired()) { // Time limit hit: abandon and conservatively report SAFE (inconclusive).
            set_details();
            return report_timeout(verdictDetails);
        }

        /* Sound termination on the exact bounds. */
        if (nodes[0].lower >= fail_prob) {
            set_details();
            return false; // proven pi-unsafe
        }
        if (nodes[0].upper < fail_prob) {
            set_details();
            return true; // pi-safe (up to epsilon-discarded mass)
        }

        /* 1) Selection: descend to a refinable, unexpanded leaf. */
        int leaf = 0;
        while (nodes[leaf].expanded) {
            int best = -1;
            double best_score = -1.0;
            for (const auto& [child_idx, trans_prob] : nodes[leaf].children) {
                if (not refinable(child_idx)) continue;
                const MctsNode& c = nodes[child_idx];
                const double gap = c.upper - c.lower;
                const double explore = ucb_c * std::sqrt(std::log(nodes[leaf].visits + 1.0) / (c.visits + 1.0));
                const double score = trans_prob * gap * (c.q + explore);
                if (score > best_score) {
                    best_score = score;
                    best = child_idx;
                }
            }
            PLAJA_ASSERT(best >= 0) // a positive parent gap implies some child with a positive gap
            leaf = best;
        }

        /* 2) Expansion: attach the successor distribution of the leaf. */
        for (const auto& [succ_id, trans_prob] : successors(nodes[leaf].state_id)) {
            MctsNode child;
            child.state_id = succ_id;
            child.path_prob = nodes[leaf].path_prob * trans_prob;
            child.parent = leaf;
            if (is_avoid_state(succ_id)) {
                child.lower = child.upper = 1.0; // avoid states are absorbing
            } else if (child.path_prob < path_epsilon) {
                child.lower = child.upper = 0.0; // discarded: optimistically counted as safe
            }
            const int child_idx = static_cast<int>(nodes.size());
            nodes.push_back(std::move(child));
            nodes[leaf].children.emplace_back(child_idx, trans_prob);
        }
        nodes[leaf].expanded = true;
        if (nodes[leaf].children.empty()) {
            nodes[leaf].lower = nodes[leaf].upper = 0.0; // terminal without reaching avoid: safe
        }

        /* 3) Rollout from the leaf to estimate P(reach avoid). */
        const double reward = nodes[leaf].children.empty() ? 0.0 : rollout(nodes[leaf].state_id);

        /* 4) Backup: rollout statistics + exact bound recomputation. */
        for (int idx = leaf; idx != -1; idx = nodes[idx].parent) {
            MctsNode& n = nodes[idx];
            ++n.visits;
            n.q += (reward - n.q) / n.visits;
            if (n.expanded and not n.children.empty()) {
                PLAJA::Prob_type lower_sum = 0.0;
                PLAJA::Prob_type upper_sum = 0.0;
                for (const auto& [child_idx, trans_prob] : n.children) {
                    lower_sum += trans_prob * nodes[child_idx].lower;
                    upper_sum += trans_prob * nodes[child_idx].upper;
                }
                n.lower = lower_sum;
                n.upper = upper_sum;
            }
        }
    }
}
