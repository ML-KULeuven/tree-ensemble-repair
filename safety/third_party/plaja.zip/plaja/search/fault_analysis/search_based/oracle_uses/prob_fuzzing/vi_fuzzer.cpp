//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

#include "vi_fuzzer.h"

#include <sstream>
#include <unordered_map>
#include <unordered_set>

bool ViFuzzer::is_state_pi_safe(StateID_type state_id) {
    // ---------- Phase 1: Build the reachable policy envelope ----------
    std::unordered_set<StateID_type> reachable;
    std::unordered_set<StateID_type> avoid_states;
    std::unordered_map<StateID_type, std::vector<std::pair<StateID_type, PLAJA::Prob_type>>> transitions;

    fuzzDeadline.restart(); // Fresh wall-clock budget for this pi-safety check (covers both phases below).

    std::vector<StateID_type> stack;
    stack.push_back(state_id);
    reachable.insert(state_id);

    while (!stack.empty()) {
        if (fuzzDeadline.expired()) { // Time limit hit during envelope build: report SAFE (inconclusive).
            return report_timeout("during reachability");
        }
        StateID_type cur_id = stack.back();
        stack.pop_back();

        if (is_avoid_state(cur_id)) {
            avoid_states.insert(cur_id);
            continue; // avoid states are absorbing for the VI; don't expand
        }

        auto& succs = transitions[cur_id];
        succs = successors(cur_id);
        for (const auto& [succ_id, trans_prob] : succs) {
            if (reachable.insert(succ_id).second) {
                stack.push_back(succ_id);
            }
        }
    }

    // ---------- Phase 2: Value iteration with early termination ----------
    // V[s] = probability of eventually reaching an avoid state from s under π.
    std::unordered_map<StateID_type, PLAJA::Prob_type> V;
    V.reserve(reachable.size());
    for (auto id : reachable) {
        V[id] = avoid_states.count(id) ? 1.0 : 0.0;
    }

    const PLAJA::Prob_type vi_tol = 1e-9;
    const int max_iters = 100000;

    for (int iter = 0; iter < max_iters; ++iter) {
        if (fuzzDeadline.expired()) { // Time limit hit during value iteration: report SAFE (inconclusive).
            return report_timeout("during value iteration");
        }
        PLAJA::Prob_type max_delta = 0.0;
        for (const auto& [s_id, succs] : transitions) {
            // s_id is non-avoid by construction (avoid states aren't in `transitions`)
            PLAJA::Prob_type new_v = 0.0;
            for (const auto& [succ_id, p] : succs) {
                new_v += p * V[succ_id];
            }
            PLAJA::Prob_type delta = new_v - V[s_id];  // monotone: new_v >= V[s_id]
            if (delta > max_delta) max_delta = delta;
            V[s_id] = new_v;
        }

        // Early termination: V[state_id] only grows; once it crosses the
        // threshold, the state is definitely unsafe.
        if (V[state_id] >= fail_prob) {
            std::ostringstream details;
            details << "mass>=" << V[state_id];
            verdictDetails = details.str();
            return false;
        }

        if (max_delta < vi_tol) break;
    }

    std::ostringstream details;
    details << "mass=" << V[state_id];
    verdictDetails = details.str();
    return true;
}
