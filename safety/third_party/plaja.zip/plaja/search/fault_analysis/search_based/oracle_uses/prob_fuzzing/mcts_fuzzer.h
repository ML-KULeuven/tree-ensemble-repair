//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

// MCTS-guided pi-safety check.
//
// Builds a search tree over the Markov chain induced by pi (branching only on
// chance outcomes; the action in every state is fixed by the policy). Like the
// DFS, the tree is unrolled per path, so revisits of a state along different
// paths get separate nodes.
//
// Every node carries bounds [lower, upper] on the conditional probability of
// eventually reaching an avoid state from it:
//   * avoid node:                       [1, 1]
//   * terminal (no successors):         [0, 0]
//   * path probability < path_epsilon:  [0, 0] (discarded, optimistically
//                                       counted as safe, as in the DFS)
//   * unexpanded leaf:                  [0, 1]
//   * expanded node:                    [sum_i p_i * lower_i, sum_i p_i * upper_i]
// The bounds are exact up to the epsilon-discarded mass, and the search
// terminates in an anytime fashion:
//   * root.lower >= fail_prob  ->  pi-UNSAFE
//   * root.upper <  fail_prob  ->  pi-safe (up to discarded mass)
//
// The Monte Carlo part only decides *which* states to explore further: the tree
// policy descends towards children maximizing
//     trans_prob * (upper - lower) * (q + c * sqrt(ln(N_parent) / N_child)),
// i.e. it prefers branches that carry a lot of still-unresolved probability
// mass and whose rollouts (q = mean rollout reward, an estimate of
// P(reach avoid)) look unsafe. Rollout statistics guide exploration but never
// influence the verdict itself.

#ifndef PLAJA_MCTS_FUZZER_H
#define PLAJA_MCTS_FUZZER_H

#include "prob_fuzzer.h"

class MctsFuzzer final : public ProbFuzzer {
    static constexpr int rollout_depth = 200; // Maximum depth of a single rollout.
    static constexpr double ucb_c = 1.4;      // UCB exploration constant for the tree policy.

    // Simulate pi from `from_id`, sampling chance outcomes; 1.0 iff an avoid
    // state was reached. Missing mass of sub-stochastic distributions counts
    // as safe termination (as in the DFS).
    [[nodiscard]] double rollout(StateID_type from_id) const;

public:
    using ProbFuzzer::ProbFuzzer;

    bool is_state_pi_safe(StateID_type state) override;
    [[nodiscard]] std::string name() const override { return "MCTS"; }
};

#endif //PLAJA_MCTS_FUZZER_H
