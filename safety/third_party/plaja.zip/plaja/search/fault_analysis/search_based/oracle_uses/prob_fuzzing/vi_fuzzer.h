//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

// Exhaustive check: build the full policy envelope reachable from the state,
// then run value iteration for the probability of reaching an avoid state.
// Terminates early (UNSAFE) as soon as the monotonically growing value of the
// checked state crosses fail_prob.

#ifndef PLAJA_VI_FUZZER_H
#define PLAJA_VI_FUZZER_H

#include "prob_fuzzer.h"

class ViFuzzer final : public ProbFuzzer {
public:
    using ProbFuzzer::ProbFuzzer;

    bool is_state_pi_safe(StateID_type state) override;
    [[nodiscard]] std::string name() const override { return "VI"; }
};

#endif //PLAJA_VI_FUZZER_H
