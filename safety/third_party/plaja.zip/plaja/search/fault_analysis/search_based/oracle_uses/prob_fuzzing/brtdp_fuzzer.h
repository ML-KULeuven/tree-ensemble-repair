//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2026) Chaahat Jain.
//

// BRTDP-style pi-safety check (bounded real-time dynamic programming /
// interval iteration on the *merged state graph*, cf. Brazdil et al., CAV'14).
//
// In contrast to DFS/MCTS, which unroll the Markov chain per *path*, every
// state gets exactly one entry with bounds [lower, upper] on the probability
// of eventually reaching an avoid state from it under pi:
//   * avoid state:               [1, 1]
//   * terminal (no successors):  [0, 0]
//   * fresh state:               [0, 1]
//   * expanded state (backup):   lower = max(lower, sum_i p_i * lower_i)
//                                upper = min(upper, sum_i p_i * upper_i)
// Bounds only ever tighten, so the check is anytime-sound:
//   * root.lower >= fail_prob  ->  definitely pi-UNSAFE
//   * root.upper <  fail_prob  ->  definitely pi-safe
//
// Exploration is trial-based: each trial walks from the root, sampling the
// successor proportional to trans_prob * (upper - lower), i.e. towards the
// largest still-unresolved probability mass, and backs the bounds up along the
// trail in reverse. When a trial runs into a cycle, plain backups can never
// close the upper bounds on it; in the Markov chain induced by pi, a closed,
// avoid-free SCC can never reach an avoid state, so a Tarjan pass over the
// explored subgraph sets upper = 0 for all states in such SCCs (the
// end-component elimination of interval iteration, specialized to Markov
// chains).
//
// Every is_state_pi_safe() call starts from a fresh state table: checks are
// completely independent of each other, so per-check comparisons against the
// other algorithms are fair.

#ifndef PLAJA_BRTDP_FUZZER_H
#define PLAJA_BRTDP_FUZZER_H

#include "prob_fuzzer.h"

#include <unordered_map>

class BrtdpFuzzer final : public ProbFuzzer {
    struct StateInfo {
        PLAJA::Prob_type lower = 0.0; // bounds on P(reach avoid | state) under pi
        PLAJA::Prob_type upper = 1.0;
        bool isAvoid = false;
        bool expanded = false;
        std::vector<std::pair<StateID_type, PLAJA::Prob_type>> succs;

        [[nodiscard]] PLAJA::Prob_type gap() const { return upper - lower; }
    };

    // Cleared at the start of every check; see file comment. (unordered_map
    // guarantees reference stability under insertion.)
    std::unordered_map<StateID_type, StateInfo> table;
    // Only run the (linear-time) SCC elimination when the explored graph has
    // grown since the last run.
    std::size_t expansions_since_scc_pass = 0;

    // Ensure a table entry exists (avoid classification happens here).
    StateInfo& init(StateID_type state_id);
    // Ensure the successor distribution of the state has been computed.
    StateInfo& expand(StateID_type state_id);
    // Bellman backup of the bounds; monotone (bounds only tighten).
    void backup(StateID_type state_id);
    // Tarjan pass over the explored subgraph: closed, avoid-free SCCs cannot
    // reach avoid, so their upper bounds drop to 0.
    void eliminate_safe_sccs();

public:
    using ProbFuzzer::ProbFuzzer;

    bool is_state_pi_safe(StateID_type state) override;
    [[nodiscard]] std::string name() const override { return "BRTDP"; }
};

#endif //PLAJA_BRTDP_FUZZER_H
