//
// Created by Daniel Sherbakov in 2025.
//

#include "policy_run_fuzzing.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <stdexcept>

PolicyRunFuzzing::PolicyRunFuzzing(
    std::function<ActionLabel_type(const State&)> policy_action,
    const Expression& unsafety_condition,
    const ObjectiveExpression& objective_condition,
    const SimulationEnvironment& simulation_env,
    const std::shared_ptr<Bias::DistanceFunction>& distance_to_avoid,
    const int lookahead_limit,
    const StopCriterion stop_criterion,
    const SelectionMethod selection_method):
    policy_action(std::move(policy_action)),
    avoid(unsafety_condition),
    objective(objective_condition),
    simulation_env(simulation_env),
    distance_to_avoid(distance_to_avoid),
    lookahead_limit(lookahead_limit),
    stop_criterion(stop_criterion),
    selection_method(selection_method) {
    if (lookahead_limit == 0) { throw std::invalid_argument("Fuzzing lookahead limit must be positive or < 0 (unbounded)."); }
}

/**
 * findContinuation(s):
 *
 *   S <- {}
 *   for d = 1, ..., D_limit:
 *       S_d <- states d steps away from s in the policy LTS
 *       if S_d is empty: return error                                    (exhausted successors)
 *       S <- S u S_d
 *       if some s' in S_d is unsafe: return shortest policy path s -> s'
 *       if stop criterion holds on S_d: break
 *   s' <- argmin_{s'' in S} h_F(s'')  or  sample from S with p(s') ~ exp(-h_F(s'))
 *   return shortest policy path s -> s'
 *
 * Layers are computed by BFS, so S_d only contains states not discovered in an earlier layer,
 * and the BFS parent pointers yield the shortest policy path to every discovered state.
 * Goal, unsafe and terminal states are absorbing, i.e., they are not expanded.
 */
std::optional<PolicyRunFuzzing::Continuation> PolicyRunFuzzing::find_continuation(StateID_type start, const Deadline& deadline) const {
    const double start_distance = h_F(start);

    ParentMap parent;                        // Also serves as the set of discovered states (besides start).
    std::vector<StateID_type> S;             // S_1 u ... u S_d
    std::vector<double> S_distances;         // h_F of the states in S (same order).
    std::vector<StateID_type> S_d = { start }; // S_0

    for (int d = 1; lookahead_limit < 0 or d <= lookahead_limit; ++d) {
        // S_d <- states d steps away from start in the policy LTS.
        std::vector<StateID_type> next_layer;
        for (const StateID_type s: S_d) {
            const State state = simulation_env.get_state(s);
            if (check_goal(state) or check_avoid(state) or check_terminal(state)) { continue; } // absorbing
            const ActionLabel_type action = policy_action(state);
            for (const StateID_type succ: simulation_env.compute_successors(state, action)) {
                if (succ == start or parent.count(succ)) { continue; } // discovered in an earlier layer
                parent.emplace(succ, std::make_pair(s, action));
                next_layer.push_back(succ);
            }
        }
        S_d = std::move(next_layer);

        if (S_d.empty()) { return std::nullopt; } // exhausted successors

        std::vector<double> layer_distances;
        layer_distances.reserve(S_d.size());
        for (const StateID_type s: S_d) {
            if (check_avoid(simulation_env.get_state(s))) { return extract_path(start, s, parent); }
            layer_distances.push_back(h_F(s));
        }
        S.insert(S.end(), S_d.begin(), S_d.end());
        S_distances.insert(S_distances.end(), layer_distances.begin(), layer_distances.end());

        if (stop_criterion_met(layer_distances, start_distance)) { break; }
        if (deadline.expired()) { break; } // select from the layers explored so far; the caller handles the timeout.
    }

    const StateID_type target = selection_method == SelectionMethod::GREEDY ? greedy_selection(S, S_distances)
                                                                            : sample_from_softmax(S, S_distances);
    return extract_path(start, target, parent);
}

/** Distance to unsafety; goal states are never preferred. */
double PolicyRunFuzzing::h_F(StateID_type state) const {
    const State s = simulation_env.get_state(state);
    if (check_goal(s)) { return std::numeric_limits<double>::infinity(); }
    return distance_to_avoid->evaluate(s);
}

bool PolicyRunFuzzing::stop_criterion_met(const std::vector<double>& layer_distances, double start_distance) const {
    const double min_distance = *std::min_element(layer_distances.begin(), layer_distances.end());
    switch (stop_criterion) {
        case StopCriterion::UNIQUE_ARGMIN: return std::count(layer_distances.begin(), layer_distances.end(), min_distance) == 1;
        case StopCriterion::IMPROVEMENT: return min_distance < start_distance;
    }
    return false;
}

/**
 * Selects a state with minimum distance.
 * If multiple states have min distance then return a uniformly random one.
 */
StateID_type PolicyRunFuzzing::greedy_selection(const std::vector<StateID_type>& states, const std::vector<double>& distances) const {
    const double min_distance = *std::min_element(distances.begin(), distances.end());
    std::vector<StateID_type> minimal_states;
    for (std::size_t i = 0; i < distances.size(); ++i) {
        if (distances[i] == min_distance) { minimal_states.push_back(states[i]); }
    }
    return minimal_states[PLAJA_GLOBAL::rng->index(minimal_states.size())];
}

/**
 * Samples a state with p(s') = exp(-h_F(s')) / sum_{s''} exp(-h_F(s'')).
 * Distances are shifted by their minimum to avoid underflow.
 * Minimal states get weight 1 explicitly, so that infinite distances (goals) are handled (inf - inf is NaN).
 */
StateID_type PolicyRunFuzzing::sample_from_softmax(const std::vector<StateID_type>& states, const std::vector<double>& distances) const {
    const double min_distance = *std::min_element(distances.begin(), distances.end());
    std::vector<double> weights;
    weights.reserve(distances.size());
    for (const double d: distances) { weights.push_back(d == min_distance ? 1.0 : std::exp(-(d - min_distance))); }

    const double p = PLAJA_GLOBAL::rng->prob() * std::accumulate(weights.begin(), weights.end(), 0.0);
    double cumulative_weight = 0.0;
    for (std::size_t i = 0; i < weights.size(); ++i) {
        cumulative_weight += weights[i];
        if (p < cumulative_weight) { return states[i]; }
    }
    return states.back();
}

/** Follows the BFS parents backwards from target to start. */
PolicyRunFuzzing::Continuation PolicyRunFuzzing::extract_path(StateID_type start, StateID_type target, const ParentMap& parent) {
    Continuation continuation;
    for (StateID_type s = target; s != start;) {
        const auto& [predecessor, action] = parent.at(s);
        continuation.states.push_back(s);
        continuation.actions.push_back(action);
        s = predecessor;
    }
    continuation.states.push_back(start);
    std::reverse(continuation.states.begin(), continuation.states.end());
    std::reverse(continuation.actions.begin(), continuation.actions.end());
    return continuation;
}

bool PolicyRunFuzzing::check_avoid(const State& state) const { return avoid.evaluateInteger(&state); }

bool PolicyRunFuzzing::check_goal(const State& state) const {
    auto* goal = objective.get_goal();
    return goal and goal->evaluateInteger(&state);
}

bool PolicyRunFuzzing::check_terminal(const State& state) const {
    auto applicable_actions = simulation_env.extract_applicable_actions(state, true);
    return applicable_actions.empty();
}
