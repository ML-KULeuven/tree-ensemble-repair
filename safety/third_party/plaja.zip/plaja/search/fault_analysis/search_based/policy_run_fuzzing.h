//
// Created by Daniel Sherbakov in 2025.
//

#ifndef POLICY_RUN_FUZZING_H
#define POLICY_RUN_FUZZING_H

#include "../../../parser/ast/expression/non_standard/objective_expression.h"
#include "../../smt/bias_functions/distance_function.h"
#include "../../fd_adaptions/state.h"
#include "../../successor_generation/simulation_environment.h"
#include "../../../utils/rng.h"
#include "deadline.h"

#include <functional>
#include <memory>
#include <optional>
#include <unordered_map>
#include <vector>

/**
 * Implements findContinuation(s) of the policy-run fuzzing algorithm:
 * a BFS over the policy LTS from s, layer by layer (S_1, S_2, ...), guided by the distance-to-unsafety h_F.
 */
class PolicyRunFuzzing {

public:
    /* When to stop expanding further layers S_d. */
    enum class StopCriterion {
        UNIQUE_ARGMIN, // argmin_{s' in S_d} h_F(s') is unique.
        IMPROVEMENT,   // min_{s' in S_d} h_F(s') < h_F(s), i.e., some state got closer to unsafety than the start.
    };

    /* How to select the continuation target among all discovered states S. */
    enum class SelectionMethod {
        GREEDY,       // argmin_{s' in S} h_F(s'), ties broken uniformly at random.
        DISTRIBUTION, // sample according to softmax over -h_F.
    };

    /* Policy path */
    struct Continuation {
        std::vector<StateID_type> states;
        std::vector<ActionLabel_type> actions; // size = states.size() - 1
    };

private:
    std::function<ActionLabel_type(const State&)> policy_action;
    const Expression& avoid;
    const ObjectiveExpression& objective;
    const SimulationEnvironment& simulation_env;
    std::shared_ptr<Bias::DistanceFunction> distance_to_avoid;

    /* Hyper parameters */
    const int lookahead_limit; // D_limit; < 0 means unbounded.
    const StopCriterion stop_criterion;
    const SelectionMethod selection_method;

    /* Pointers of the BFS: state -> (predecessor, policy action in predecessor). */
    using ParentMap = std::unordered_map<StateID_type, std::pair<StateID_type, ActionLabel_type>>;

    [[nodiscard]] double h_F(StateID_type state) const;
    [[nodiscard]] bool stop_criterion_met(const std::vector<double>& layer_distances, double start_distance) const;

    [[nodiscard]] StateID_type greedy_selection(const std::vector<StateID_type>& states, const std::vector<double>& distances) const;
    [[nodiscard]] StateID_type sample_from_softmax(const std::vector<StateID_type>& states, const std::vector<double>& distances) const;

    [[nodiscard]] static Continuation extract_path(StateID_type start, StateID_type target, const ParentMap& parent);

    [[nodiscard]] bool check_avoid(const State& state) const;
    [[nodiscard]] bool check_goal(const State& state) const;
    [[nodiscard]] bool check_terminal(const State& state) const;

public:
    PolicyRunFuzzing(
        std::function<ActionLabel_type(const State&)> policy_action,
        const Expression& unsafety_condition,
        const ObjectiveExpression& objective_condition,
        const SimulationEnvironment& simulation_env,
        const std::shared_ptr<Bias::DistanceFunction>& distance_to_avoid,
        int lookahead_limit,
        StopCriterion stop_criterion,
        SelectionMethod selection_method
    );

    /**
     * findContinuation(s).
     * @return shortest policy path from start to the selected state (or to an unsafe state, if one is found),
     * or std::nullopt ("error") if the policy envelope of start is exhausted without reaching an unsafe state.
     * If the deadline expires, layer expansion stops and a state is selected from the layers explored so far.
     */
    [[nodiscard]] std::optional<Continuation> find_continuation(StateID_type start, const Deadline& deadline) const;
};

#endif //POLICY_RUN_FUZZING_H
