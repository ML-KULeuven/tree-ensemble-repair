//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2024) Chaahat Jain.
//

#ifndef PLAJA_DEADLINE_H
#define PLAJA_DEADLINE_H

#include <chrono>

/*
 * Cooperative wall-clock budget for otherwise-unbounded loops (policy-run path sampling, DFS and VI
 * pi-safety checks, oracle safety/fault queries, Tarjan SCC computation, ...). These searches can
 * explore an enormous or effectively infinite state space, so each long-running loop polls expired()
 * and bails when the budget is spent. The limit is configurable (in seconds); a non-positive limit
 * means "unlimited" and disables the check. restart() must be called at the start of each top-level
 * operation so every operation gets the full budget.
 */
class Deadline {
    double limitSeconds;                              // <= 0 means unlimited.
    std::chrono::steady_clock::time_point startedAt;  // When the current operation started (for elapsed()).
    std::chrono::steady_clock::time_point deadline;   // Wall-clock instant at which the budget expires.

public:
    explicit Deadline(double limit_seconds = 0.0): limitSeconds(limit_seconds) { restart(); }

    /* (Re)start the budget from now; call at the beginning of each top-level operation. */
    void restart() {
        startedAt = std::chrono::steady_clock::now();
        // Skip the deadline computation when unlimited: limitSeconds can be huge (e.g. DBL_MAX), and
        // casting that to steady_clock::duration would overflow.
        deadline = unlimited()
                 ? startedAt
                 : startedAt + std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(limitSeconds));
    }

    [[nodiscard]] bool unlimited() const { return limitSeconds <= 0.0; }

    /* True once the budget for the current operation has been exhausted. */
    [[nodiscard]] bool expired() const {
        return not unlimited() and std::chrono::steady_clock::now() > deadline;
    }

    /* Seconds elapsed since the last restart(); useful for recording how long an operation took. */
    [[nodiscard]] double elapsed_seconds() const {
        return std::chrono::duration<double>(std::chrono::steady_clock::now() - startedAt).count();
    }

    [[nodiscard]] double limit_seconds() const { return limitSeconds; }
};

#endif //PLAJA_DEADLINE_H
