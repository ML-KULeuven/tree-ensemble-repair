//
// This file is part of the PlaJA code base.
// Copyright (c) (2023 - 2024) Chaahat Jain.
//

#include <z3++.h>
#include "ensemble_sat_checker_z3.h"
#include "../../../../parser/ast/expression/non_standard/predicates_expression.h"
#include "../../../../stats/stats_base.h"
#include "../../../information/jani2ensemble/jani_2_ensemble.h"
#include "../../../information/input_feature_to_jani.h"
#include "../../../smt/solver/smt_solver_z3.h"
#include "../../../smt/solver/solution_check_wrapper_z3.h"
#include "../../../smt/solver/solution_z3.h"
#include "../../../smt/constraint_z3.h"
#include "../../../smt/context_z3.h"
#include "../../../smt/vars_in_z3.h"
#include "../../../smt_ensemble/solver/solver_veritas.h"
#include "../../../smt_ensemble/to_z3/veritas_to_z3.h"
#include "../../pa_states/abstract_state.h"
#include "../../successor_generation/action_op/action_op_pa.h"
#include "../../smt/model_z3_pa.h"
#include "../../solution_checker_pa.h"
#include "../../solution_checker_instance_pa.h"
#include "../smt/action_op_veritas_pa.h"
#include "../smt/model_veritas_pa.h"

EnsembleSatCheckerZ3::EnsembleSatCheckerZ3(const Jani2Ensemble& jani_2_ensemble, const PLAJA::Configuration& config):
    EnsembleSatInZ3Base(jani_2_ensemble, config)
    , ensembleSatSolver(new Z3_IN_PLAJA::SMTSolver(modelZ3.share_context())) {

    ensemble_as_query = modelVeritas->make_query(true, false, 0);

    // ensemble variables
    variables = std::make_unique<Z3_IN_PLAJA::VeritasToZ3Vars>(modelZ3.get_context(), modelVeritas->get_context(), Z3_IN_PLAJA::VeritasToZ3Vars::reuse(modelZ3.get_src_vars(), modelVeritas->get_state_indexes(0)), ensemble_as_query->get_input_query());

    // add bounds for source variables (inputs + predicates)
    for (auto it = jani2Ensemble->init_input_feature_iterator(true); !it.end(); ++it) {
        if (not it.get_input_feature()->is_location()) { modelZ3.register_src_bound(*ensembleSatSolver, it.get_input_feature()->get_variable_id()); }
    }
    for (auto pred_it = modelZ3._predicates()->predicatesIterator(); !pred_it.end(); ++pred_it) { modelZ3.register_src_bounds(*ensembleSatSolver, *pred_it); }

    // ensembleSatSolver->dump_solver_to_file("z3_query.z3");
}

EnsembleSatCheckerZ3::~EnsembleSatCheckerZ3() = default;
//

void EnsembleSatCheckerZ3::load_policy(ActionLabel_type action_label) {
// Add variables for each tree and output label.
    auto trees = jani2Ensemble->load_ensemble();

    // NOTE: no applicability-filter trees here. The tree-based filter (leaf penalties of
    // negative_infinity over operator indicator variables) is only needed for back-ends that
    // must express applicability inside the ensemble. In z3 we encode applicability natively
    // in the output interface instead (see add_output_interface_z3).
    variables->add_tree_vars(trees);
    // NOTE: tree variables (per-tree leaf values) and output-label variables (their
    // per-label sums) are internal computation variables and must stay unbounded.
    // Do NOT clamp them to [negative_infinity, infinity]: those are finite sentinels
    // (-200000 / 100000) used for input-feature ranges. The applicability filter
    // penalizes inapplicable actions with a leaf value of exactly negative_infinity,
    // so a penalized label's summed output drops below -200000, which would make the
    // `output == sum` constraint contradict the lower bound and force the whole query
    // spuriously UNSAT. z3 reals are unbounded by default, matching the Gurobi encoding.

    // Load policy:
    ensembleSatSolver->add(VERITAS_TO_Z3::generate_ensemble_forwarding_structures(trees, *variables));
    
    // output interface
    outputInterfacePerIndex = VERITAS_TO_Z3::generate_output_interfaces(jani2Ensemble->load_ensemble(), *variables);

}

void EnsembleSatCheckerZ3::add_source_state_z3() {
    PLAJA_ASSERT(set_source_state)
    const auto& source = *set_source_state; // quick fix to make code more readable and more flexible towards adaptions of set_source_state

    // locations
    auto& c = modelZ3.get_context();
    const auto& veritas_vars = modelVeritas->get_state_indexes();
    for (const VariableIndex_type state_index: modelVeritas->get_input_locations()) {
        ensembleSatSolver->add(variables->to_z3_expr(veritas_vars.to_veritas(state_index)) == c().int_val(source.location_value(state_index)));
    }

    // add predicate constraints
    for (auto pred_it = source.init_pred_state_iterator(); !pred_it.end(); ++pred_it) {
        if (pred_it.predicate_value()) { ensembleSatSolver->add(modelZ3.get_src_predicate(pred_it.predicate_index())); }
        else { ensembleSatSolver->add(!modelZ3.get_src_predicate(pred_it.predicate_index())); }
    }

}

void EnsembleSatCheckerZ3::add_guard_z3() {
    PLAJA_ASSERT(set_action_op)
    modelZ3.get_action_op_pa(set_action_op_id).add_to_solver(*ensembleSatSolver);
}

void EnsembleSatCheckerZ3::add_guard_negation_z3() {
    PLAJA_ASSERT(set_action_op)
    const auto& action_op = modelZ3.get_action_op_pa(set_action_op_id);
    action_op.add_src_bounds(*ensembleSatSolver);
    ensembleSatSolver->add(!action_op._guards());
}

void EnsembleSatCheckerZ3::add_update_z3() {
    PLAJA_ASSERT(set_action_op)
    PLAJA_ASSERT(set_update_index != ACTION::noneUpdate)
    const auto& update = modelZ3.get_action_op_pa(set_action_op_id).get_update_pa(set_update_index);
    update.add_to_solver(*ensembleSatSolver);

}

void EnsembleSatCheckerZ3::add_target_predicate_state_z3() {
    PLAJA_ASSERT(set_action_op)
    PLAJA_ASSERT(set_update_index != ACTION::noneUpdate)
    PLAJA_ASSERT(set_target_state)
    const auto& update = modelZ3.get_action_op_pa(set_action_op_id).get_update_pa(set_update_index);
    update.add_predicates_to_solver(*ensembleSatSolver, *set_target_state);
}

z3::expr EnsembleSatCheckerZ3::action_applicable_z3(ActionLabel_type action_label) const {
    // A labeled action is applicable iff some of its operators is applicable:
    // disjunction of guards (including source-location constraints) over the shared source vars.
    auto& c = modelZ3.get_context();
    z3::expr applicable = c().bool_val(false);
    for (const auto* action_op: modelZ3.get_action_ops(action_label)) {
        applicable = applicable || action_op->guard_to_z3(modelZ3.get_src_vars(), true)->move_to_expr();
    }
    return applicable;
}

void EnsembleSatCheckerZ3::add_output_interface_z3() {
    PLAJA_ASSERT(set_output_index != NEURON_INDEX::none)
    if (jani2Ensemble->_do_applicability_filtering()) {
        // Applicability-aware output interface: the policy selects the queried action iff its
        // output value is maximal among the *applicable* actions. Inapplicable rivals do not
        // compete, so for each rival output j: applicable(j) -> output[a] >= output[j].
        // Ties count as SAT (>=), consistent with the Veritas/Gurobi back-ends.
        const z3::expr& output_var = variables->output_label_to_z3_expr(set_output_index);
        const auto num_outputs = jani2Ensemble->get_num_output_features();
        for (OutputIndex_type output_index = 0; output_index < num_outputs; ++output_index) {
            if (output_index == set_output_index) { continue; }
            const auto rival_label = jani2Ensemble->get_output_label(output_index);
            ensembleSatSolver->add(z3::implies(action_applicable_z3(rival_label), output_var >= variables->output_label_to_z3_expr(output_index)));
        }
        return;
    }

    ensembleSatSolver->add(outputInterfacePerIndex[set_output_index]);
    // ensembleSatSolver->dump_solver_to_file("output_interface.z3");
}

bool EnsembleSatCheckerZ3::check_z3() {
    ensembleSatSolver->push();
    
    add_source_state_z3(); // we always expect the source state
    PLAJA_ASSERT(set_action_op) // NN-SAT(S,g,a)
    PLAJA_ASSERT(set_output_index == jani2Ensemble->get_output_index(set_action_op->_action_label())) // sanity check
    add_guard_z3();
    PLAJA_ASSERT(set_update_index != ACTION::noneUpdate)
    add_update_z3();
    add_target_predicate_state_z3(); // if update index is set, we also expect a target state
    load_policy(set_output_index); // load policy with app filter trees
    add_output_interface_z3(); // as well as the action label --> NN-SAT(S,a)

    // ensembleSatSolver->dump_solver_to_file("z3_query.z3");
    const bool rlt = ensembleSatSolver->check();

    // extract solution
    if constexpr (PLAJA_GLOBAL::reuseSolutions) {
        if (rlt) {
            lastSolution = ensembleSatSolver->extract_solution_via_checker(modelZ3, std::make_unique<SolutionCheckerInstancePa>(*solutionChecker, set_source_state.get(), set_action_label, set_action_op->_op_id(), set_update_index, set_target_state.get()));
            PLAJA_ASSERT(solutionChecker->check(*lastSolution->get_solution(0), set_source_state.get(), set_action_label, set_action_op->_op_id(), set_update_index, set_target_state.get(), set_target_state ? lastSolution->get_solution(1) : nullptr))
        }
    }

    if (sharedStatistics) { // maintain exact stats
        sharedStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::ENSEMBLE_SAT_QUERIES_Z3); // usually we set this prior to query; however ...
        if (ensembleSatSolver->retrieve_unknown()) { sharedStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::ENSEMBLE_SAT_QUERIES_Z3_UNDECIDED); }
        else if (!rlt) { sharedStatistics->inc_attr_unsigned(PLAJA::StatsUnsigned::ENSEMBLE_SAT_QUERIES_Z3_UNSAT); }
    }

    ensembleSatSolver->pop();
    ensembleSatSolver->reset(); // reset after each query
    return rlt;
}

bool EnsembleSatCheckerZ3::check_() {
        return check_z3();
}
