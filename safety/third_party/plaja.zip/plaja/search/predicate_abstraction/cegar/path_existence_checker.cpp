//
// This file is part of the PlaJA code base.
// Copyright (c) (2019 - 2022) Marcel Vinzent.
// See README.md in the top-level directory for licensing information.
//

#include "path_existence_checker.h"
#include "../../../parser/ast/expression/non_standard/predicates_expression.h"
#include "../../../parser/visitor/extern/to_normalform.h"
#include "../../factories/configuration.h"
#include "../../factories/predicate_abstraction/pa_options.h"
#include "../../information/jani2nnet/jani_2_nnet.h"
#include "../../information/model_information.h"
#include "../../states/state_values.h"
#include "../../successor_generation/action_op.h"
#include "../../smt/solver/smt_solver_z3.h"
#include "../../smt/solver/solution_z3.h"
#include "../../smt/successor_generation/action_op_to_z3.h"
#include "../../smt/utils/to_z3_expr_splits.h"
#include "../../smt/visitor/extern/to_z3_visitor.h"
#include "../../smt/vars_in_z3.h"
#include "../../smt/constraint_z3.h"
#include "../../smt_nn/solver/smt_solver_marabou.h"
#include "../pa_states/abstract_path.h"
#include "../pa_states/abstract_state.h"
#include "../nn/smt/model_marabou_pa.h"
#include "../solution_checker_instance_pa.h"
#include "../smt/model_z3_pa.h"
#include "spuriousness_result.h"
#include "selection_refinement.h"


#ifdef USE_VERITAS
    #include "../ensemble/smt/model_veritas_pa.h"
    #include "../../smt_ensemble/solver/solver_veritas.h"
    #include "../../information/jani2ensemble/jani_2_ensemble.h"
#endif

/*
 * PathExistenceChecker -- the solver back-end of the CEGAR spuriousness check in Policy Predicate
 * Abstraction (Vinzent et al.). Given a candidate abstract counterexample path (a sequence of
 * predicate/abstract states linked by operators that ends in the unsafe `reach` condition), it
 * answers two questions:
 *   1. Standard PA: is the abstract path concretizable at all (ignoring the policy)?  -> check* /
 *      check_incrementally. On failure it classifies WHY (Concretization / GuardApp / Terminal /
 *      Target) and harvests the offending atoms as new refinement predicates.
 *   2. Policy-aware: does the policy actually select the operators along that path?    -> check_policy /
 *      check_policy_incrementally. On failure it reports ActionSel and a witness for the refiner.
 * It wraps three solver back-ends behind one interface: Z3 (transition + abstraction logic, always
 * present), Marabou (NN policy), and Veritas (tree-ensemble policy).
 */

/*
 * Constructor: wire up the solver back-ends. Z3 (the abstraction reasoner) is always built. The
 * policy reasoner is then chosen by representation: a neural policy uses Marabou, otherwise (under
 * USE_VERITAS) a tree-ensemble policy uses Veritas. Models are shared via the Configuration so
 * sibling checkers reuse the same encodings. `paStateIsTerminalExact` records whether terminality is
 * encoded exactly as predicates (see check_terminal()).
 */
PathExistenceChecker::PathExistenceChecker(const PLAJA::Configuration& configuration, const PredicatesStructure& predicates):
    predicates(&predicates)
    , solutionChecker(nullptr)
    , modelZ3(nullptr)
    , solver(nullptr)
    , modelMarabou(nullptr)
    , solverMarabou(nullptr)
CONSTRUCT_IF_TERMINAL_STATE_SUPPORT(paStateIsTerminalExact(configuration.get_bool_option(PLAJA_OPTION::terminal_as_preds))) {

    /* The Z3 abstraction model is shared across checkers: reuse it if present, else build and register it. */
    if (configuration.has_sharable(PLAJA::SharableKey::MODEL_Z3)) {

        modelZ3 = configuration.get_sharable_cast<ModelZ3, ModelZ3PA>(PLAJA::SharableKey::MODEL_Z3);

    } else {

        modelZ3 = std::make_shared<ModelZ3PA>(configuration);

        configuration.set_sharable<ModelZ3>(PLAJA::SharableKey::MODEL_Z3, modelZ3);
    }

    /* Z3 solver over the shared context handles all transition/abstraction (non-policy) reasoning. */
    solver = std::make_unique<Z3_IN_PLAJA::SMTSolver>(modelZ3->share_context(), configuration.get_sharable_ptr<PLAJA::StatsBase>(PLAJA::SharableKey::STATS));

    /* Pick the policy back-end by representation: Marabou for an NN policy, Veritas for a tree ensemble. */
    if (modelZ3->has_nn()) {

        if (configuration.has_sharable(PLAJA::SharableKey::MODEL_MARABOU)) {

            modelMarabou = configuration.get_sharable_cast<ModelMarabou, ModelMarabouPA>(PLAJA::SharableKey::MODEL_MARABOU);
            modelSmt = configuration.get_sharable_cast<ModelMarabou, ModelMarabouPA>(PLAJA::SharableKey::MODEL_MARABOU);

        } else {

            modelMarabou = std::make_shared<ModelMarabouPA>(configuration);
            auto marabouModel = std::make_shared<ModelMarabouPA>(configuration);
            configuration.set_sharable<ModelMarabou>(PLAJA::SharableKey::MODEL_MARABOU, marabouModel); // cannot use modelSmt for this just yet. Annoying
            modelSmt = configuration.get_sharable_cast<ModelMarabou, ModelMarabouPA>(PLAJA::SharableKey::MODEL_MARABOU);

        }

        /* Marabou solver for NN policy queries, plus a concrete solution checker over the NN model. */
        solverMarabou = MARABOU_IN_PLAJA::SMT_SOLVER::construct(configuration, modelMarabou->make_query(false, false, 0));

        solutionChecker = std::make_unique<SolutionCheckerPa>(configuration, modelMarabou->get_model(), modelMarabou->get_interface());

    } else {
        #ifdef USE_VERITAS
        /* No NN -> the policy is a tree ensemble; build/reuse the shared Veritas model and its solver. */
        PLAJA_ASSERT(modelZ3->has_ensemble())
        if (not configuration.has_sharable(PLAJA::SharableKey::MODEL_VERITAS)) {
            auto veritasModel = std::make_shared<ModelVeritasPA>(configuration);
            configuration.set_sharable<ModelVeritas>(PLAJA::SharableKey::MODEL_VERITAS, veritasModel);
        }
        
        modelSmt = configuration.get_sharable_cast<ModelVeritas, ModelVeritasPA>(PLAJA::SharableKey::MODEL_VERITAS);
        auto modelVeritas = configuration.get_sharable_cast<ModelVeritas, ModelVeritasPA>(PLAJA::SharableKey::MODEL_VERITAS);
        solverSmt = VERITAS_IN_PLAJA::ENSEMBLE_SOLVER::construct(configuration, *modelVeritas->make_query(false, false, 0));

        solutionChecker = std::make_unique<SolutionCheckerPa>(configuration, modelVeritas->get_model(), modelVeritas->get_interface());
        #endif
    }

}

PathExistenceChecker::~PathExistenceChecker() = default;

//

/* Thin forwarding accessors onto the shared Z3 model: the model owns the problem's static data
 * (start region, unsafe `reach` target, non-terminal condition, the interface, location flags) and
 * the checker just exposes it. `do_locs()` reports whether locations are part of the encoding. */

void PathExistenceChecker::set_interface(const class Jani2Interface* interface) { modelZ3->set_interface(interface); }

const Expression* PathExistenceChecker::get_start() const { return modelZ3->get_start(); }

const Expression* PathExistenceChecker::get_reach() const { return modelZ3->get_reach(); }

const class Jani2Interface* PathExistenceChecker::get_interface() const { return modelZ3->get_interface(); }

bool PathExistenceChecker::has_interface() const { return modelZ3->has_interface(); }

bool PathExistenceChecker::has_nn() const { return modelZ3->has_nn(); }

#ifdef USE_VERITAS
bool PathExistenceChecker::has_ensemble() const { return modelZ3->has_ensemble(); }
#endif

const Expression* PathExistenceChecker::get_non_terminal() const { return modelZ3->get_non_terminal(); }

Z3_IN_PLAJA::Context& PathExistenceChecker::get_context() const { return modelZ3->get_context(); }

inline bool PathExistenceChecker::do_locs() const { return not modelZ3->ignore_locs(); }

/**********************************************************************************************************************/

/*
 * Debug-only sanity probe: assert the current solver state can only be NON-terminal at `step`.
 * We temporarily push the terminal constraint and expect UNSAT (hence "entailed non-terminal"). Used
 * to assert the invariant that, when we are NOT explicitly excluding terminal states, the surrounding
 * constraints already forbid terminality at that step.
 */
bool PathExistenceChecker::check_entailed_non_terminal(Z3_IN_PLAJA::SMTSolver& solver_ref, StepIndex_type step) const {
    PLAJA_ABORT_IF(not PLAJA_GLOBAL::debug)
    if constexpr (not PLAJA_GLOBAL::enableTerminalStateSupport) { return true; }
    if (not modelZ3->get_terminal()) { return true; }
    solver_ref.push();
    modelZ3->add_terminal(solver_ref, step);                 // Hypothesis: this state IS terminal ...
    return not solver_ref.check_pop();                       // ... if that is UNSAT, non-terminality is entailed.
}

/*
 * Pin down the start of the trajectory at step 0. Two flavours: an explicit `start` region (optionally
 * intersected with the model init), or just the model init when the problem includes it.
 */
inline void PathExistenceChecker::encode_start(Z3_IN_PLAJA::SMTSolver& query, const SolutionCheckerInstancePaPath& problem) const {

    if (problem.get_start()) {
        PLAJA_ASSERT(modelZ3->get_start() == problem.get_start())
        modelZ3->add_start(query, problem.includes_init());
    } else if (problem.includes_init()) { modelZ3->add_init(query, 0); }

}

/*
 * Encode the WHOLE abstract path into a Z3 solver in one shot (no per-step probing). Used by the
 * monolithic policy check. Lays down, in order: start-step variable bounds, the start region, then per
 * step [abstract state | terminal handling | next-step bounds | operator (guard+update)], and finally
 * the target abstract state, terminal handling and the unsafe `reach` condition.
 *
 * The pa-state-aware switch is the key choice (see header): when state-aware we assert membership in
 * the abstract (predicate) state at EVERY step -- the literal PPA abstract path. When NOT state-aware
 * we constrain only the endpoints (step 0 always, and the target), letting the operator chaining
 * determine the intermediate concrete states without forcing them into the path's abstract labels.
 */
void PathExistenceChecker::encode_path(Z3_IN_PLAJA::SMTSolver& query, const SolutionCheckerInstancePaPath& problem) const {

    const auto& path = problem.get_path();

    PLAJA_ASSERT(path.get_state_path_size() >= 2)

    modelZ3->generate_steps(path.get_size());

    modelZ3->add_bounds(query, path.get_start_step(), not do_locs());
    encode_start(query, problem);

    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {

        /* Pa state: every step if state-aware, otherwise only the start (step 0 must always be pinned). */
        if (problem.is_pa_state_aware() or path_it.get_step() == 0) { modelZ3->add_to(path_it.get_pa_state(), query, path_it.get_step()); }

        /* Terminal: explicitly forbid terminality unless the abstract state already encodes it exactly. */
        if (check_terminal(problem.is_pa_state_aware())) { modelZ3->exclude_terminal(query, path_it.get_step()); }
        else { PLAJA_ASSERT(check_entailed_non_terminal(query, path_it.get_step())) } // Otherwise it must be entailed.

        /* Vars: declare/bound the successor step's state variables. */
        modelZ3->add_bounds(query, path_it.get_step() + 1, not do_locs());

        /* Op: guard applicability + the chosen update, linking this step to its successor. */
        modelZ3->add_action_op(query, path_it.get_op_id(), path_it.get_update_index(), do_locs(), true, path_it.get_step());

    }

    /* Pa state: the target abstract state is only asserted when state-aware (otherwise endpoint = reach only). */
    if (problem.is_pa_state_aware()) { modelZ3->add_to(path.get_pa_target_state(), query, path.get_target_step()); }

    /* Terminal: forbid a terminal target unless the unsafe condition is allowed to coincide with terminal. */
    if (check_terminal(problem.is_pa_state_aware()) and not PLAJA_GLOBAL::reachMayBeTerminal) { modelZ3->exclude_terminal(query, path.get_target_step()); }
    else { PLAJA_ASSERT(check_terminal(problem.is_pa_state_aware()) or check_entailed_non_terminal(query, path.get_target_step())) }

    /* Reach: the unsafe target condition the counterexample claims to reach. */
    if (problem.get_reach()) {
        PLAJA_ASSERT(modelZ3->get_reach() == problem.get_reach())
        modelZ3->add_reach(query, path.get_target_step());
    }

    /* Terminal sanity (debug): when reach may be terminal, confirm the target is genuinely non-terminal here. */
    if (PLAJA_GLOBAL::debug and PLAJA_GLOBAL::enableTerminalStateSupport and PLAJA_GLOBAL::reachMayBeTerminal and modelZ3->get_terminal()) {
        query.push();
        modelZ3->add_terminal(query, path.get_target_step());
        PLAJA_ASSERT_EXPECT(not query.check_pop())
    }
}

/*
 * Marabou twin of encode_path: same skeleton (start, per-step abstract state / op / terminal, then
 * target abstract state / terminal / reach) but targeting the Marabou query so the NN policy can be
 * layered on top by the caller. Differences: `start` is rewritten via a Z3 optimization pass (Marabou
 * needs a concrete optimized start expression), and step bounds are the caller's responsibility.
 * The same pa-state-aware endpoint-vs-every-step rule for asserting abstract states applies.
 */
void PathExistenceChecker::encode_path(MARABOU_IN_PLAJA::SMTSolver& query, const SolutionCheckerInstancePaPath& problem) const {
    const auto& path = problem.get_path();

    PLAJA_ASSERT(path.get_state_path_size() >= 1)

    // modelMarabou->generate_steps(path.size()); // responsibility of callee as query must have been initialized apropriately

    PLAJA_ASSERT(not(problem.get_start() and problem.includes_init()))

    if (problem.get_start()) {

        // optimize start
        // if (optimize_start) {
        /* Marabou needs a concrete start: encode the path in a throwaway Z3 solver and optimize the
         * start expression against it, then feed the optimized start into the Marabou query. */
        Z3_IN_PLAJA::SMTSolver solver_tmp(modelZ3->share_context(), solver->share_statistics());
        encode_path(solver_tmp, problem);
        modelMarabou->add_to_query(query, *modelZ3->optimize_expression(*modelMarabou->get_start(), solver_tmp, false, false, false, false), path.get_start_step());
        // }
        // else { modelMarabou->add_start(query); }

    } else if (problem.includes_init()) { modelMarabou->add_init(query, path.get_start_step()); }

    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {

        /* Abstract state: every step if state-aware, else only the start step. */
        if (problem.is_pa_state_aware() or path_it.get_step() == path.get_start_step()) { modelMarabou->add_to(path_it.get_pa_state(), query, path_it.get_step()); }

        /* Op: guard + chosen update linking step to successor. */
        modelMarabou->add_action_op(query, path_it.get_op_id(), path_it.get_update_index(), do_locs(), true, path_it.get_step());

        /* Terminal. */ // TODO optimize
        if (check_terminal(problem.is_pa_state_aware())) { modelMarabou->exclude_terminal(query, path_it.get_step()); }

    }

    /* Pa state: target abstract state only under state-aware mode. */
    if (problem.is_pa_state_aware()) { modelMarabou->add_to(path.get_pa_target_state(), query, path.get_target_step()); }

    /* Terminal. */
    if (check_terminal(problem.is_pa_state_aware()) and not PLAJA_GLOBAL::reachMayBeTerminal) { modelMarabou->exclude_terminal(query, path.get_target_step()); }

    /* Reach */
    if (problem.get_reach()) {
        PLAJA_ASSERT(modelZ3->get_reach() == problem.get_reach()) // modelMarabou does not work, since here start is rewritten.
        modelMarabou->add_reach(query, path.get_target_step());
    }

}

/**********************************************************************************************************************/

/*
 * One-step satisfiability probe: is the intersection of the start region with `abstract_state`
 * non-empty? I.e. does the abstraction admit any concrete start state in this abstract state. Used to
 * decide whether an abstract state is a feasible entry point before exploring paths from it.
 */
bool PathExistenceChecker::check_start(const AbstractState& abstract_state, bool include_model_init) {
    modelZ3->generate_steps(1);
    auto& solver_ = *solver;
    solver_.clear();
    PLAJA_ASSERT(solver_.get_stack_size() == 1)
    solver_.push(); // to suppress scoped_timer thread in z3, which is started when using tactic2solver
    modelZ3->add_bounds(solver_, 0, not do_locs());
    modelZ3->add_start(solver_, include_model_init);    // Start/init region ...
    modelZ3->add_to(abstract_state, solver_, 0);        // ... intersected with the abstract state.
    return solver_.check();
}

/*
 * Monolithic concretization check under STANDARD PA (no policy): build the entire path query at once
 * and return a single SAT/UNSAT. SAT == the abstract path is concretizable (some concrete trajectory
 * threads it and reaches the unsafe target). Unlike check_incrementally this gives no breakdown of
 * WHERE/why it failed -- it is the fast yes/no variant.
 */
bool PathExistenceChecker::check(const SolutionCheckerInstancePaPath& problem) {
    PLAJA_ASSERT(not do_locs()) // not properly supported

    const auto& path = problem.get_path();
    PLAJA_ASSERT(path.get_state_path_size() >= 2) // Expect actual path.
    /* TODO Might enable checking of path prefix only, but for now we assert: */
    PLAJA_ASSERT(problem.get_target_step() == path.get_size()) // StepIndex is state path length - 1.

    modelZ3->generate_steps(path.get_size());

    auto& solver_ = *solver;
    solver_.clear();
    PLAJA_ASSERT(solver_.get_stack_size() == 1)
    solver_.push(); // To suppress scoped_timer thread in z3, which is started when using tactic2solver.

    /* Start vars. */
    modelZ3->add_bounds(solver_, path.get_start_step(), not do_locs());

    /* Start. */
    encode_start(solver_, problem);

    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {

        /* Predicates (optional): abstract-state membership -- every step when state-aware, else only step 0. */
        if (problem.is_pa_state_aware() or path_it.get_step() == 0) { // Must always assert abstract start state.
            PLAJA_ASSERT(path_it.get_step() > 0 or solver_.check())
            modelZ3->add_to(path_it.get_pa_state(), solver_, path_it.get_step());
        }

        /* Terminal: forbid terminality unless the abstract state already encodes it exactly. */
        if (check_terminal(problem.is_pa_state_aware())) { modelZ3->exclude_terminal(solver_, path_it.get_step()); }
        else { PLAJA_ASSERT(check_entailed_non_terminal(solver_, path_it.get_step())) }

        /* NN select: if a policy target is set, encode the NN and tie its output to the chosen op (policy-aware). */
        if (modelZ3->has_nn() and path_it.get_step() < problem.get_policy_target_step()) {
            modelZ3->add_nn(solver_, path_it.get_step());
            modelZ3->add_output_interface_for_op(solver_, path_it.get_op_id(), path_it.get_step());
        }

        #ifdef USE_VERITAS
        /* Tree ensembles are not encoded into Z3 -- their policy check goes through Veritas, not here. */
        if (modelZ3->has_ensemble() and path_it.get_step() < problem.get_policy_target_step()) {
            PLAJA_LOG("add ensemble to z3?")
            PLAJA_ABORT
        }
        #endif

        /* Action op structure: guard applicability + chosen update, chaining this step to its successor. */
        modelZ3->add_action_op(solver_, path_it.get_op_id(), path_it.get_update_index(), do_locs(), true, path_it.get_step());

        /* Target vars: declare/bound the successor step's variables. */
        modelZ3->add_bounds(solver_, path_it.get_successor_step(), not do_locs());
    }

    /* Predicates: target abstract state, only under state-aware mode. */
    if (problem.is_pa_state_aware()) {
        PLAJA_ASSERT(path.get_target_step() > 0)
        modelZ3->add_to(path.get_pa_target_state(), solver_, path.get_target_step());
    }

    /* Terminal: forbid a terminal target unless reach is allowed to coincide with terminal. */
    if (check_terminal(problem.is_pa_state_aware()) and not PLAJA_GLOBAL::reachMayBeTerminal) { modelZ3->exclude_terminal(solver_, path.get_target_step()); }
    else { PLAJA_ASSERT(check_terminal(problem.is_pa_state_aware()) or check_entailed_non_terminal(solver_, path.get_target_step())) }

    /* Reach: the unsafe condition the path claims to reach. */
    if (problem.get_reach()) {
        PLAJA_ASSERT(modelZ3->get_reach() == problem.get_reach())
        modelZ3->add_reach(solver_, path.get_target_step());
    }
    /* Terminal sanity (debug): confirm the target is genuinely non-terminal when reach may be terminal. */
    if (PLAJA_GLOBAL::debug and PLAJA_GLOBAL::enableTerminalStateSupport and PLAJA_GLOBAL::reachMayBeTerminal and modelZ3->get_terminal()) {
        solver_.push();
        modelZ3->add_terminal(solver_, path.get_target_step());
        PLAJA_ASSERT_EXPECT(not solver_.check_pop())
    }

    return solver_.check(); // SAT == path concretizable under standard PA.

}

/**********************************************************************************************************************/

/*
 * Harvest the predicates of `abstract_state` as candidate refinement predicates at `step`. Two modes:
 *  - exclude-entailment: only emit a predicate whose NEGATION is still satisfiable given the current
 *    solver state (i.e. the predicate is not already entailed) -- avoids re-adding predicates the
 *    context already implies, keeping the refinement minimal.
 *  - otherwise: emit all (set) predicates unconditionally.
 * Under lazy PA only the SET predicates carry a value and are considered.
 */
void PathExistenceChecker::add_predicates_aux(SpuriousnessResult& result, StepIndex_type step, const AbstractState& abstract_state, Z3_IN_PLAJA::SMTSolver& solver_) const {

    if (result.do_exclude_entailment()) { // Add non-entailed predicate (values) only.

        for (auto pred_it = abstract_state.init_pred_state_iterator(); !pred_it.end(); ++pred_it) {
            PLAJA_ASSERT(PLAJA_GLOBAL::lazyPA or pred_it.is_set())
            if constexpr (PLAJA_GLOBAL::lazyPA) { if (not pred_it.is_set()) { continue; } } // Lazy PA: skip unset predicates.

            if (pred_it.predicate_value()) {

                /* Predicate is positive in the abstract state: it is non-entailed iff its negation is SAT here. */
                if (solver_.check_push_pop(!modelZ3->get_predicate_z3(pred_it.predicate_index(), step))) {
                    result.add_refinement_predicate(pred_it.predicate_index(), step);
                }

            } else {

                /* Predicate is negative: non-entailed iff the predicate itself is still SAT here. */
                if (solver_.check_push_pop(modelZ3->get_predicate_z3(pred_it.predicate_index(), step))) {
                    result.add_refinement_predicate(pred_it.predicate_index(), step);
                }

            }

        }

    } else {

        /* No entailment filtering: take every (set) predicate as a refinement predicate. */
        for (auto pred_it = abstract_state.init_pred_state_iterator(); !pred_it.end(); ++pred_it) {
            PLAJA_ASSERT(PLAJA_GLOBAL::lazyPA or pred_it.is_set())
            if constexpr (PLAJA_GLOBAL::lazyPA) { if (not pred_it.is_set()) { continue; } }
            result.add_refinement_predicate(pred_it.predicate_index(), step);
        }

    }
}

/*
 * Add the abstract-state membership constraint at `step` and test feasibility. This is the
 * Concretization spuriousness reason: if asserting the predicates makes the path UNSAT, the abstract
 * state cannot be concretized here -> mark spurious and emit the (non-entailed) predicates that
 * separate it. Returns true iff spurious (caller should stop and refine). Mirrors the pa-state-aware
 * rule: membership is only asserted when state-aware (or at step 0, which is always pinned).
 */
bool PathExistenceChecker::add_predicates(SpuriousnessResult& result, StepIndex_type step, const AbstractState& abstract_state, Z3_IN_PLAJA::SMTSolver& solver_, bool pa_state_aware) {
    PLAJA_ASSERT(not pa_state_aware or modelZ3->_predicates()->equals(abstract_state.get_predicates()))

    /* Optionally pre-collect refinement predicates before they get asserted (external-add mode). */
    if (result.do_add_non_entailed_predicates_externally()) { add_predicates_aux(result, step, abstract_state, solver_); }

    if (pa_state_aware or step == 0) { // Must always assert abstract start state.

        /* When excluding entailment but not yet harvesting externally, push so we can still probe entailment after. */
        const bool need_to_push = result.do_exclude_entailment() and not result.do_add_non_entailed_guards_externally();
        if (need_to_push) { solver_.push(); } // Must still check predicate entailment.

        modelZ3->add_to(abstract_state, solver_, step); // Assert membership in the abstract state.

        if (not solver_.check()) { // Infeasible -> the abstract state is not concretizable at this step.

            if (need_to_push) { solver_.pop(); } // Must still check predicate entailment.

            PLAJA_ASSERT(step > 0)
            result.set_spurious(SpuriousnessResult::Concretization);

            /* If not already done, we still need to add the (non-entailed) predicate (values). */
            if (not result.do_add_non_entailed_predicates_externally()) { add_predicates_aux(result, step, abstract_state, solver_); }

            return true; // Spurious: caller stops and refines.
        }

    }

    return false; // Feasible so far.
}

/*
 * Add the non-terminality constraint at `step` and test feasibility (the Terminal spuriousness
 * reason). If excluding terminal makes the path UNSAT, the state is forced terminal where the path
 * assumes it can continue -> mark spurious and emit the non-entailed splits of the non-terminal
 * condition as refinement predicates. Returns true iff still feasible (non-terminal achievable).
 * Reuses the guard machinery (add_guards) since terminal is treated like a guard condition.
 */
bool PathExistenceChecker::add_terminal(SpuriousnessResult& result, StepIndex_type step, Z3_IN_PLAJA::SMTSolver& solver_) {

    if (not PLAJA_GLOBAL::enableTerminalStateSupport or not solutionChecker->get_terminal()) { return true; }

    const auto& vars_smt = modelZ3->get_state_vars(step);

    // TODO: for now use guard config for terminal.
    /* External-add mode: harvest the non-terminal condition's atoms as refinement predicates up front. */
    if (result.do_add_non_entailed_guards_externally()) {
        auto terminal_splits = Z3_IN_PLAJA::to_z3_condition_splits(*modelZ3->get_non_terminal(), vars_smt);
        add_guards(result, step, *terminal_splits, solver_);
    }

    const bool need_to_push = result.do_exclude_entailment() and not result.do_add_non_entailed_guards_externally();
    if (need_to_push) { solver_.push(); } // Must still check guard entailment.

    modelZ3->exclude_terminal(solver_, step); // Assert the state is non-terminal.

    if (not solver_.check()) { // Now check path existence -- UNSAT means the state is forced terminal.

        if (need_to_push) { solver_.pop(); } // Must still check guard entailment.

        result.set_spurious(SpuriousnessResult::Terminal);

        /* If not already done, we still need to add the (non-entailed) guards. */
        if (not result.do_add_non_entailed_guards_externally()) {
            auto terminal_splits = Z3_IN_PLAJA::to_z3_condition_splits(*modelZ3->get_non_terminal(), vars_smt);
            add_guards(result, step, *terminal_splits, solver_);
        }

        return false; // Spurious (terminal).

    }

    return true; // Non-terminal is achievable.
}

/*
 * Emit the atomic linear splits of a condition (guard / non-terminal / reach) as refinement
 * predicates at `step`. With entailment exclusion, only splits whose negation is still SAT (i.e. not
 * already entailed by the context) are added -- the minimal set that actually changes the abstraction.
 * Without it, every split is added.
 */
void PathExistenceChecker::add_guards(SpuriousnessResult& result, StepIndex_type step, ToZ3ExprSplits& splits, Z3_IN_PLAJA::SMTSolver& solver) {

    if (result.do_exclude_entailment()) {
        for (auto it = splits.iterator(); !it.end(); ++it) {
            if (solver.check_push_pop(!it.split_z3())) { result.add_refinement_predicate(it.move_split(), step); } // Non-entailed only.
        }
    } else { for (auto it = splits.iterator(); !it.end(); ++it) { result.add_refinement_predicate(it.move_split(), step); } }

}

/**********************************************************************************************************************/

/*
 * The workhorse standard-PA concretization check. Unlike the monolithic check(), this walks the path
 * STEP BY STEP, adding constraints and probing satisfiability after each, so it can pinpoint the first
 * point of failure and classify the spuriousness reason -- feeding the refiner the right predicates:
 *   - add_predicates  -> Concretization (abstract-state membership infeasible)
 *   - add_terminal    -> Terminal       (state forced terminal where the path continues)
 *   - guard block     -> GuardApp       (operator not applicable)
 *   - reach block     -> Target         (unsafe condition unsatisfiable at the end)
 * If every step survives, the path is genuinely concretizable: it extracts a concrete witness
 * trajectory (concretization) and returns a non-spurious result. The returned SpuriousnessResult owns
 * the problem instance (moved in) and accumulates the prefix length / refinement predicates.
 */
std::unique_ptr<SpuriousnessResult> PathExistenceChecker::check_incrementally(std::unique_ptr<SolutionCheckerInstancePaPath>&& problem) {
    PLAJA_ASSERT(not do_locs()) // not properly supported

    const auto& path = problem->get_path();
    PLAJA_ASSERT(path.get_state_path_size() >= 2) // Expect actual path.
    PLAJA_ASSERT(problem->get_target_step() == path.get_size()) // StepIndex is state path length - 1.
    PLAJA_ASSERT(problem->get_policy_target_step() == 0)

    modelZ3->generate_steps(path.get_size());

    auto& solver_ = *solver;
    solver_.clear();
    PLAJA_ASSERT(solver_.get_stack_size() == 1)
    solver_.push(); // To suppress scoped_timer thread in z3, which is started when using tactic2solver.

    /* Start vars. */
    modelZ3->add_bounds(solver_, path.get_start_step(), not do_locs());

    /* Start. */
    encode_start(solver_, *problem);

    /* Result owns the problem from here; it accumulates spuriousness reason, prefix length and predicates. */
    const auto* problem_ptr = problem.get();
    std::unique_ptr<SpuriousnessResult> result(new SpuriousnessResult(*predicates, std::move(problem)));

    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {
        const auto& src_vars = modelZ3->get_state_vars(path_it.get_step());
        const auto& action_op = modelZ3->get_action_op_structure(path_it.get_op_id());
        const UpdateIndex_type update_index = path_it.get_update_index();

        PLAJA_ASSERT(solver_.check()) // Invariant: everything asserted so far is still satisfiable.

        /* Abstract state: bail with Concretization if membership is infeasible here. */
        if (add_predicates(*result, path_it.get_step(), path_it.get_pa_state(), solver_, problem_ptr->is_pa_state_aware())) { return result; }

        /* Terminal: bail with Terminal if the state is forced terminal where the path continues. */
        if (check_terminal(problem_ptr->is_pa_state_aware()) and not add_terminal(*result, path_it.get_step(), solver_)) { return result; }
        else { PLAJA_ASSERT(check_terminal(problem_ptr->is_pa_state_aware()) or check_entailed_non_terminal(solver_, path_it.get_step())) }
        /* Guard. */

        /* TODO we split the guards down to atomic linear constraints and add these as predicates.
         * However, when excluding entailment, we might apply this on the disjunction level,
         * i.e., only adding atomic linear constraints for non entailed disjunctions.
         * In principle same holds true for reach/terminal condition. */
        if (result->do_add_non_entailed_guards_externally()) { // We add the non-entailed guards either way.
            auto guard_splits = action_op.guard_to_z3_splits(src_vars);
            add_guards(*result, path_it.get_step(), *guard_splits, solver_);
        }

        const bool need_to_push = result->do_exclude_entailment() and not result->do_add_non_entailed_guards_externally();
        if (need_to_push) { solver_.push(); } // Must still check guard entailment.

        action_op.guard_to_z3(src_vars, do_locs())->add_to_solver(solver_); // Assert the operator guard.

        if (not solver_.check()) { // Now check path existence -- UNSAT means the guard is not applicable.

            if (need_to_push) { solver_.pop(); } // Must still check guard entailment.

            result->set_spurious(SpuriousnessResult::GuardApp);

            /* If not already done, we still need to add the (non-entailed) guards. */
            if (not result->do_add_non_entailed_guards_externally()) {
                auto guard_splits = action_op.guard_to_z3_splits(src_vars);
                add_guards(*result, path_it.get_step(), *guard_splits, solver_);
            }

            return result; // Spurious (guard).

        }

        /* */

        /* Target vars: declare/bound the successor state variables. */
        modelZ3->add_bounds(solver_, path_it.get_successor_step(), not do_locs());

        /* Update: apply the chosen update, deterministically linking this step to its successor. */
        action_op.update_to_z3(update_index, src_vars, modelZ3->get_state_vars(path_it.get_successor_step()), do_locs(), true)->add_to_solver(solver_);
        PLAJA_ASSERT(solver_.check()) // Update is functional, so this must stay SAT.

        /* Set prefix: record how far the path is confirmed concretizable. */
        result->set_prefix_length(path_it.get_successor_step());
    }

    /* Abstract state: target membership (Concretization reason at the end). */
    if (add_predicates(*result, path.get_target_step(), path.get_pa_target_state(), solver_, problem_ptr->is_pa_state_aware())) { return result; }

    /* Terminal: target must be non-terminal unless reach may coincide with terminal. */
    if (check_terminal(problem_ptr->is_pa_state_aware()) and not PLAJA_GLOBAL::reachMayBeTerminal) { if (not add_terminal(*result, path.get_target_step(), solver_)) { return result; } }
    else { PLAJA_ASSERT(check_terminal(problem_ptr->is_pa_state_aware()) or check_entailed_non_terminal(solver_, path.get_target_step())) }

    /* Finally must check target condition.*/

    if (result->do_exclude_entailment()) { solver_.push(); } // Must still check target entailment.

    // solver_.add(target_splits->_splits_in_z3()); This does not work for disjunctions.
    modelZ3->add_reach(solver_, path.get_target_step()); // Assert the unsafe target condition.

    /* Terminal sanity (debug). */
    if (PLAJA_GLOBAL::debug and PLAJA_GLOBAL::enableTerminalStateSupport and PLAJA_GLOBAL::reachMayBeTerminal and modelZ3->get_terminal()) {
        solver_.push();
        modelZ3->add_terminal(solver_, path.get_target_step());
        PLAJA_ASSERT_EXPECT(not solver_.check_pop())
    }

    if (not solver_.check()) { // Unsafe condition unreachable at the end -> Target spuriousness.

        if (result->do_exclude_entailment()) { solver_.pop(); } // Must still check target entailment.

        result->set_spurious(SpuriousnessResult::Target);

        const auto& target_vars = modelZ3->get_state_vars(path.get_target_step());
        auto target_splits = Z3_IN_PLAJA::to_z3_condition_splits(*modelZ3->get_reach(), target_vars);
        PathExistenceChecker::add_guards(*result, path.get_target_step(), *target_splits, solver_);

        return result; // Spurious (target).

    }

    /* Extract solution: path is genuinely concretizable -> materialize a concrete witness trajectory. */
    result->set_concretization(solver->extract_solution_via_checker(*modelZ3, result->get_path_instance().copy_problem())->retrieve_solution_vector());
    PLAJA_ASSERT(not result->get_path_instance().is_invalidated())

    return result; // Non-spurious under standard PA (policy check, if any, happens separately).

}

/*
 * Policy-aware check (NN only): run AFTER standard-PA concretization has succeeded. It re-encodes the
 * path into a Marabou query and additionally constrains the NN so that, at each step, the policy's
 * output actually selects the path's operator. SAT == the policy genuinely induces this trajectory
 * (real counterexample); UNSAT == the path is policy-spurious (ActionSel). Monolithic yes/no variant.
 */
bool PathExistenceChecker::check_policy(const SolutionCheckerInstancePaPath& problem) {
    PLAJA_ASSERT(not do_locs()) // Probably not properly supported.
    PLAJA_ASSERT(modelZ3->has_nn())

    const auto& path = problem.get_path();
    PLAJA_ASSERT(problem.get_target_step() == path.get_size()) // StepIndex is state path length - 1
    PLAJA_ASSERT(problem.get_policy_target_step() == problem.get_target_step())

    modelMarabou->generate_steps(path.get_state_path_size());
    auto& solver_marabou = *solverMarabou;
    solver_marabou.set_query(modelMarabou->make_query(false, true, path.get_size() - 1));
    PLAJA_ASSERT(path.get_state_path_size() >= 1)

    // TODO maybe swap order (NN, path without NN)

    /* Path without NN: the transition/abstraction skeleton. */
    encode_path(solver_marabou, problem);

    /* NN: add the network and tie its output to the chosen op at every step (the policy-selection constraint). */
    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {
        modelMarabou->add_nn_to_query(solver_marabou._query(), path_it.get_step());
        modelMarabou->add_output_interface_for_op(solver_marabou._query(), path_it.get_op_id(), path_it.get_step());
    }

    solver_marabou.set_solution_checker(*modelMarabou, problem.copy_problem());
    const bool rlt = solver_marabou.check(); // SAT == policy induces the path.
    solver_marabou.unset_solution_checker();
    return rlt;
}

/*
 * Incremental, warm-started policy-aware check (NN only). Like check_policy but step-by-step and it
 * exploits the concretization already found by check_incrementally: it first tries to REUSE that
 * concrete solution (advancing the policy target one step at a time and just re-checking it), only
 * invoking the expensive Marabou solve when the cached solution stops selecting the right action.
 * On the first step where no concrete state lets the policy pick the path's action it reports
 * ActionSel and hands the witness + the offending concrete state to the SelectionRefinement (which
 * synthesizes predicates separating "policy selects this action" from the reached state). If all steps
 * pass, it caches the concretization. This is exactly the ActionSel path mirrored for Veritas in
 * spuriousness_checker.cpp.
 */
std::unique_ptr<SpuriousnessResult> PathExistenceChecker::check_policy_incrementally(std::unique_ptr<SolutionCheckerInstancePaPath>&& problem, const SelectionRefinement& selection_refinement) {
    PLAJA_ASSERT(not do_locs()) // not properly supported
    PLAJA_ASSERT(modelZ3->has_nn())

    const auto& path = problem->get_path();
    PLAJA_ASSERT(problem->get_target_step() == path.get_size()) // StepIndex is state path length - 1
    PLAJA_ASSERT(problem->get_policy_target_step() == problem->get_target_step())

    modelMarabou->generate_steps(path.get_state_path_size());
    auto& solver_marabou = *solverMarabou;
    solver_marabou.set_query(modelMarabou->make_query(false, true, path.get_size() - 1));
    PLAJA_ASSERT(path.get_state_path_size() >= 1)

    /*
     * We expect that PathExistenceChecker's z3 solver has been successfully called on the non-policy-restricted path problem
     * and problem comes with a matching concretization.
     */
    /* Seed the reusable concretization from the standard-PA solution; policy target starts at step 0. */
    auto solution_checker_instance = problem->copy_problem();
    solution_checker_instance->set_policy_target(path.get_start_step());
    PLAJA_ASSERT(not problem->is_invalidated())
    solution_checker_instance->set_solution(problem->retrieve_solution_vector());
    PLAJA_ASSERT(solution_checker_instance->check())
    bool current_instance_solution_is_good = true; // Whether the cached concretization still selects correctly.

    encode_path(solver_marabou, *problem);

    if constexpr (PLAJA_GLOBAL::debug) {
        solver_marabou.set_solution_checker(*modelMarabou, solution_checker_instance->copy_problem());
        PLAJA_ASSERT(solver_marabou.check())
        auto sanity_instance = solver_marabou.extract_solution_via_checker();
        PLAJA_ASSERT(not sanity_instance or sanity_instance->check())
    }

    const auto* problem_ptr = problem.get();
    std::unique_ptr<SpuriousnessResult> result(new SpuriousnessResult(*predicates, std::move(problem)));

    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {

        PLAJA_LOG_DEBUG(PLAJA_UTILS::string_f("Step %i", path_it.get_step()))

        /* Add nn structures for current step (network + output-to-op binding = policy selection). */
        modelMarabou->add_nn_to_query(solver_marabou._query(), path_it.get_step());
        modelMarabou->add_output_interface_for_op(solver_marabou._query(), path_it.get_op_id(), path_it.get_step());

        /* Try to reuse previous solution: advance its policy target one step and re-check (cheap path). */
        if (current_instance_solution_is_good) {
            solution_checker_instance->inc_policy_target();

            if (solution_checker_instance->check()) {
                result->set_prefix_length(path_it.get_successor_step()); // Set prefix.
                continue;                                                // Cached solution still selects correctly.
            } else {
                current_instance_solution_is_good = false; // Keep as backup for concretization.
            }

        }

        /* Cached solution failed -> Check (with fresh instance) via a full Marabou solve at this step. */
        solver_marabou.set_solution_checker(*modelMarabou, std::make_unique<SolutionCheckerInstancePaPath>(*solutionChecker, path, path.get_target_step(), path_it.get_successor_step(), problem_ptr->is_pa_state_aware(), problem_ptr->get_start(), problem_ptr->includes_init(), problem_ptr->get_reach()));
        const bool rlt = solver_marabou.check();

        if (rlt) { // Some concrete state still lets the policy pick this action -> continue.
            PLAJA_ASSERT(not current_instance_solution_is_good)

            /* If check found a valid solution, we cache the fresh solution instance. */
            auto fresh_instance = PLAJA_UTILS::cast_unique<SolutionCheckerInstancePaPath>(solver_marabou.extract_solution_via_checker());
            if (fresh_instance) {
                PLAJA_ASSERT(not fresh_instance->is_invalidated())
                PLAJA_ASSERT(fresh_instance->check())
                solution_checker_instance = std::move(fresh_instance); // New warm-start basis.
                current_instance_solution_is_good = true;
            }

            result->set_prefix_length(path_it.get_successor_step()); // Set prefix.

        } else { // No concrete state selects this action -> policy-spurious here.
            PLAJA_ASSERT(not current_instance_solution_is_good)

            result->set_spurious(SpuriousnessResult::ActionSel);

            /* Refine on the witness (policy DOES select the action) vs. the reached state (it does NOT). */
            PLAJA_ASSERT(not solution_checker_instance->is_invalidated())
            PLAJA_ASSERT(not get_interface()->is_chosen(*solution_checker_instance->get_solution(path_it.get_step()), path_it.retrieve_label()))
            selection_refinement.add_refinement_preds(*result, path_it.retrieve_label(), path_it.get_witness().get(), solution_checker_instance->get_solution(path_it.get_step()));

            solver_marabou.unset_solution_checker();
            return result; // Spurious (action selection).

        }

    }

    /* Cache concretization: if the warm-started solution survived all steps, it is a genuine policy run. */
    if (current_instance_solution_is_good) {
        PLAJA_ASSERT(solution_checker_instance->get_solution_size() == path.get_state_path_size())
        result->set_concretization(solution_checker_instance->retrieve_solution_vector());
    }

    return result;

}

/* */

/*
 * Bounded reachability probe -- a different mode from the path checks above. Instead of testing a
 * given abstract path, it unrolls the model `number_of_steps` from the REAL init and asks whether the
 * unsafe `reach` condition is satisfiable within that horizon. With `nn_aware` the policy (NN) is
 * forwarded at each step so the search respects action selection; otherwise it explores all choices.
 * Used for bootstrapping / sanity (e.g. is the property even reachable in k steps).
 */
bool PathExistenceChecker::check(unsigned int number_of_steps, bool nn_aware) {
    modelZ3->generate_steps(number_of_steps);

    auto& solver_ = *solver;
    solver_.clear();
    PLAJA_ASSERT(solver_.get_stack_size() == 1)
    solver_.push(); // To suppress scoped_timer thread in z3, which is started when using tactic2solver.

    modelZ3->add_bounds(solver_, 0, false);
    modelZ3->add_start(solver_, true); // Start from the real model init.

    for (StepIndex_type step_index = 0; step_index < number_of_steps; ++step_index) {
        /* Forwarding: encode the NN so transitions follow the policy (policy-aware horizon). */
        if (nn_aware) { modelZ3->add_nn(solver_, step_index); }
        /* Terminal: keep the run alive (exclude terminal) at each step. */
        if (check_terminal(false)) { modelZ3->exclude_terminal(solver_, step_index); }
        /* Choice point: branch over applicable ops (constrained to the policy choice when nn_aware). */
        modelZ3->add_choice_point(solver_, step_index, nn_aware);
        /* Successor bounds. */
        modelZ3->add_bounds(solver_, step_index + 1, false);
    }

    /* Terminal. */
    if (check_terminal(false) and not PLAJA_GLOBAL::reachMayBeTerminal) { modelZ3->exclude_terminal(solver_, number_of_steps); }

    /* Target condition. */
    if (modelZ3->get_reach()) { modelZ3->add_reach(solver_, number_of_steps); }

    /* Terminal sanity. */
    if (PLAJA_GLOBAL::debug and PLAJA_GLOBAL::enableTerminalStateSupport and PLAJA_GLOBAL::reachMayBeTerminal and modelZ3->get_terminal()) {
        solver_.push();
        modelZ3->add_terminal(solver_, number_of_steps);
        PLAJA_ASSERT_EXPECT(not solver_.check_pop())
    }

    return solver_.check();

}

/* */

/*
 * Debug helper: materialize a concrete solution from the current solver state and print the concrete
 * state at every step of the trajectory. Purely diagnostic.
 */
void PathExistenceChecker::dump_solution(std::unique_ptr<SolutionCheckerInstance>&& solution_checker_instance) const {

    solution_checker_instance = solver->extract_solution_via_checker(*modelZ3, std::move(solution_checker_instance));

    for (StepIndex_type step = 0; step < solution_checker_instance->get_solution_size(); ++step) {
        PLAJA_LOG(PLAJA_UTILS::string_f("--- Step %i ---", step))
        solution_checker_instance->get_solution(step)->dump(&modelZ3->get_model());
    }

    // Deprecated:
    // const auto solution = solver->get_solution();
    // modelZ3->get_state_vars(0).extract_solution(*solution, state, do_locs());
    // solver->add(modelZ3->get_state_vars(0).encode_solution(*solution, do_locs()));

#if 0
    // nn vars:
    if (include_nn_vars) {
        PLAJA_LOG("NN output variables:")
        for (auto it = modelZ3->iterate_path(); !it.end(); ++it) {
            const auto& nn_vars = modelZ3->get_nn_vars(it.step());
            PLAJA_LOG(PLAJA_UTILS::string_f("--- Step %i ---", it.step()))
            for (const auto output_var: nn_vars._output_features()) {
                PLAJA_LOG((nn_vars[output_var] == PLAJA::SMTSolver::eval(nn_vars[output_var], m)).to_string())
            }
        }
    }
#endif

}
