//
// This file is part of the PlaJA code base.
// Copyright (c) (2019 - 2022) Marcel Vinzent.
// See README.md in the top-level directory for licensing information.
//

#include "spuriousness_checker.h"
#include "../../../parser/visitor/extern/to_normalform.h"
#include "../../../utils/structs_utils/update_op_ref.h"
#include "../../factories/predicate_abstraction/pa_options.h"
#include "../../factories/configuration.h"
#include "../../successor_generation/action_op.h"
#include "../pa_states/abstract_path.h"
#include "../pa_states/abstract_state.h"
#include "../solution_checker_pa.h"
#include "../solution_checker_instance_pa.h"
#include "spuriousness_result.h"
#include "path_existence_checker.h"
#include "../../information/jani_2_interface.h"
#ifdef USE_VERITAS
#include "interval.hpp"
#endif

/*
 * Construct the spuriousness checker. Wires up the helpers needed to decide whether an abstract
 * unsafe path is concretizable, and, if not, how to refine the abstraction.
 */
SpuriousnessChecker::SpuriousnessChecker(const PLAJA::Configuration& configuration, const PredicatesStructure& predicates_ref):
    predicates(&predicates_ref)                                                                  // Current set of abstraction predicates.
    , pathExistenceChecker(nullptr)                                                              // Built below; performs the SMT/transition feasibility checks.
    , paStateAware(configuration.get_bool_option(PLAJA_OPTION::pa_state_aware))                  // Whether abstract-state membership is checked along the path.
    , checkPolicySpuriousness(configuration.get_bool_option(PLAJA_OPTION::check_policy_spuriousness)) // Whether to additionally run the policy-aware check.
    , encounteredNonDetUpdate(false) {                                                           // Set during a path check if a non-deterministic update is seen.

    /* We need the planning model to be available as a sharable constant. */
    PLAJA_ASSERT(configuration.has_sharable_const(PLAJA::SharableKey::MODEL));

    /* Owns the feasibility checks (guard/transition/target, incremental SMT, etc.). */
    pathExistenceChecker = std::make_unique<PathExistenceChecker>(configuration, *predicates);

    /* Build the component that turns a policy-selection violation into new refinement predicates. */
    if (pathExistenceChecker->has_nn()) {
        /* Neural-network policy: refinement is driven by the NN interface. */
        PLAJA_ASSERT(pathExistenceChecker->get_interface())
        selectionRefinement = std::make_unique<SelectionRefinement>(configuration, *pathExistenceChecker->get_interface());
    } else {
        #ifdef USE_VERITAS
        /* Tree-ensemble policy (Veritas build): same component, ensemble-backed interface. */
        PLAJA_LOG("Inside spuriousness checker, ensembles refinement")
        selectionRefinement = std::make_unique<SelectionRefinement>(configuration, *pathExistenceChecker->get_interface());
        #endif
    }

}

SpuriousnessChecker::~SpuriousnessChecker() = default;

/**********************************************************************************************************************/

/*
 * Take a (possibly compound) predicate, break it into atomic linear pieces, and register as
 * refinement predicates exactly those atoms that the given concrete state violates. Used whenever
 * spuriousness is caused by a condition (terminal/guard/target) that the concrete state fails:
 * adding the violated atoms to the abstraction lets future searches distinguish this state.
 */
inline void SpuriousnessChecker::add_relevant_pred_split(SpuriousnessResult& spuriousness_result, const Expression& predicate, const StateBase& state) {
    /* Split into atomic predicates; keep them linear (do not multiply out) so they stay usable. */
    auto split_predicates = TO_NORMALFORM::normalize_and_split(predicate, false); // to preserve linearity
    for (auto& split_pred: split_predicates) {
        /* Only the atoms that the state does NOT satisfy are the relevant ones to add. */
        if (split_pred->evaluate_integer(state)) { continue; } // Split is satisfied, no need to add.
        /* Register the violated atom, tagged with the prefix length where the violation occurred. */
        spuriousness_result.add_refinement_predicate(std::move(split_pred), spuriousness_result.get_spurious_prefix_length());
    }
}

/*
 * Concretization-mismatch refinement. The abstract state fixes a truth value for each predicate;
 * the concrete state may disagree on some of them (so the concrete state is not actually a member
 * of the abstract state). Register every such disagreeing predicate as a refinement predicate so
 * the abstraction stops claiming this concrete state belongs to that abstract state.
 */
void SpuriousnessChecker::add_violated_predicates(SpuriousnessResult& spuriousness_result, const AbstractState& abstract_state, const StateBase& state) {
    /* Iterate over the predicates that define this abstract state. */
    for (auto it = abstract_state.init_pred_state_iterator(); !it.end(); ++it) {
        const auto& predicate = it.predicate();
        /* In non-lazy PA every predicate has a fixed value; in lazy PA some may be unset -> skip. */
        PLAJA_ASSERT(PLAJA_GLOBAL::lazyPA or it.is_set())
        if constexpr (PLAJA_GLOBAL::lazyPA) { if (not it.is_set()) { continue; } }
        /* Disagreement: abstract state's assumed value differs from the concrete evaluation. */
        if (it.predicate_value() != predicate.evaluate_integer(state)) {
            PLAJA_ASSERT(not predicate.is_constant())                                    // A constant could never disagree.
            PLAJA_ASSERT(TO_NORMALFORM::normalize_and_split(predicate, true).size() == 1) // Abstraction predicates are atomic.
            /* Add the already-existing predicate (by index), tagged with the violating prefix. */
            spuriousness_result.add_refinement_predicate(it.predicate_index(), spuriousness_result.get_spurious_prefix_length());
        }
    }
}

/*
 * Transition-feasibility spuriousness check (deterministic concretization).
 *
 * Replays the abstract path concretely, starting from a fixed concrete state (already placed at
 * step 0 of path_instance), computing each successor deterministically. At every step it verifies
 * that the concrete trajectory respects: abstract-state membership, non-terminality, and guard
 * applicability; at the end it verifies the target/reach (unsafe) condition. The first failing
 * check marks the path spurious, records the appropriate refinement predicates, and returns early.
 *
 * This routine does NOT consider the policy; that is layered on top by check_path_nn().
 */
std::unique_ptr<SpuriousnessResult> SpuriousnessChecker::check_path(std::unique_ptr<SolutionCheckerInstancePaPath>&& path_instance) const {
    STMT_IF_DEBUG(constexpr bool debug_log = false;)
    PLAJA_LOG_DEBUG_IF(debug_log, "Checking path concretization ...")

    const auto& solution_checker = path_instance->get_checker_pa();   // Evaluates guards/updates/abstraction against concrete states.
    const auto& path = path_instance->get_path();                     // The abstract path under test.

    /* Sanity: a concrete seed state exists at step 0, sizes/targets line up, flags match. */
    PLAJA_ASSERT(path_instance->get_solution(0))
    PLAJA_ASSERT(path_instance->get_solution_size() == path.get_state_path_size())
    PLAJA_ASSERT(path_instance->get_target_step() == path.get_state_path_size() - 1)
    PLAJA_ASSERT(path_instance->get_policy_target_step() == path.get_start_step())
    PLAJA_ASSERT(path_instance->is_pa_state_aware() == paStateAware) // For convenience.

    const auto* current = path_instance->get_solution(0);            // Concrete state we are tracing forward.
    const StateValues* successor; // NOLINT(*-init-variables)

    /* The seed state must be a member of the path's source abstract state. */
    PLAJA_ASSERT(solution_checker.check_state_and_abstraction(*current, path.get_pa_source_state()))

    /* Result accumulator; takes ownership of the path instance so successors can be cached in it. */
    auto* path_instance_ptr = path_instance.get();
    std::unique_ptr<SpuriousnessResult> result(new SpuriousnessResult(*predicates, std::move(path_instance)));

    /* Replay each abstract step concretely. */
    std::cout << "Starting to concretize abstract unsafe path" << std::endl;
    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {
        PLAJA_LOG_DEBUG_IF(debug_log, "Path Step.")

        /* Tag subsequent refinement predicates with the current step index. */
        result->set_prefix_length(path_it.get_step());

        const auto& action_op = solution_checker.get_action_op(path_it.get_op_id()); // Operator taken at this step.
        const UpdateIndex_type update_index = path_it.get_update_index();            // Which (possibly branching) update arm.

        /* (1) Abstract-state membership: does the concrete state still lie in this step's abstract state? */
        const auto& abstract_state = path_it.get_pa_state();
        if (paStateAware and not abstract_state.is_abstraction(*current)) {
            /* Concretization left the abstract state -> spurious; refine on the disagreeing predicates. */
            result->set_spurious(SpuriousnessResult::Concretization);
            add_violated_predicates(*result, abstract_state, *current);
            return result;
        } else if (result->do_add_non_entailed_predicates_externally()) { add_violated_predicates(*result, abstract_state, *current); }
        PLAJA_LOG_DEBUG_IF(debug_log and paStateAware, "Abstract state good.")

        /* (2) Non-terminality: a terminal state has no outgoing transition, so the path is impossible. */
        if (PLAJA_GLOBAL::enableTerminalStateSupport and solution_checker.check_terminal(*current)) {
            result->set_spurious(SpuriousnessResult::Terminal);
            PLAJA_ASSERT(pathExistenceChecker->get_non_terminal())
            /* Refine by adding the violated atoms of the "non-terminal" condition. */
            add_relevant_pred_split(*result, *pathExistenceChecker->get_non_terminal(), *current);
        }
        PLAJA_LOG_DEBUG_IF(debug_log and solution_checker.get_terminal(), "Non-terminal state good.")

        /* (3) Guard applicability: the operator must be enabled in the concrete state. */
        if (not action_op.is_enabled(*current)) { // Op is not enabled.
            result->set_spurious(SpuriousnessResult::GuardApp);
            /* Refine on every violated atom of the guard conjunction. */
            for (auto it_guard = action_op.guardIterator(); !it_guard.end(); ++it_guard) {
                SpuriousnessChecker::add_relevant_pred_split(*result, *it_guard, *current);
            }
            return result;
        }
        PLAJA_LOG_DEBUG_IF(debug_log, "Guard applicability good.")

        /* Check selection (done in check_path_nn). */

        /* (4) Compute the concrete successor for this step (or reuse a cached one). */
        const auto successor_step = path_it.get_successor_step();
        successor = path_instance_ptr->get_solution(successor_step);
        /* Remember if any update is non-deterministic; downstream this forces an SMT check for completeness. */
        encounteredNonDetUpdate = encounteredNonDetUpdate or action_op.get_update(update_index).is_non_deterministic(0);
        if (successor) {
            PLAJA_ASSERT_EXPECT(false) // Not expected here: successors are usually computed fresh below.
            PLAJA_ASSERT(solution_checker.agrees(*current, action_op, update_index, *successor))
        } else {
            /* Apply the update deterministically and cache the resulting successor state. */
            path_instance_ptr->set_solution(std::make_unique<StateValues>(solution_checker.compute_successor_solution(*current, action_op, update_index)), successor_step);
            successor = path_instance_ptr->get_solution(successor_step);
        }
        PLAJA_ASSERT(successor)

        /* Advance the prefix tag to the successor step. */
        result->set_prefix_length(path_it.get_successor_step());

        /* Step forward. */
        current = successor;
    }
    std::cout << "Concretization completed" << std::endl;

    /* (1') Final-state abstract membership in the target abstract state. */
    const auto& abstract_target_state = path.get_pa_target_state();
    if (paStateAware and not abstract_target_state.is_abstraction(*current)) {

        result->set_spurious(SpuriousnessResult::Concretization);
        add_violated_predicates(*result, path.get_pa_target_state(), *current);
        return result;

    } else if (result->do_add_non_entailed_predicates_externally()) { add_violated_predicates(*result, abstract_target_state, *current); }
    PLAJA_LOG_DEBUG_IF(debug_log and paStateAware, "Abstract target state good.")

    /* (2') Final-state non-terminality (unless the target is itself allowed to be terminal). */
    if (PLAJA_GLOBAL::enableTerminalStateSupport and not PLAJA_GLOBAL::reachMayBeTerminal and solution_checker.check_terminal(*current)) {
        result->set_spurious(SpuriousnessResult::Terminal);
        PLAJA_ASSERT(pathExistenceChecker->get_non_terminal())
        add_relevant_pred_split(*result, *pathExistenceChecker->get_non_terminal(), *current);
    } else if constexpr (PLAJA_GLOBAL::reachMayBeTerminal) { PLAJA_ASSERT_EXPECT(not solution_checker.check_terminal(*current)) }
    PLAJA_LOG_DEBUG_IF(debug_log and solution_checker.get_terminal(), "Non-terminal state good.")


    /* (5) Target/reach condition: the final concrete state must actually be unsafe. */
    const auto* reach = pathExistenceChecker->get_reach();
    PLAJA_ASSERT(reach)
    if (not reach->evaluate_integer(*current)) {

        PLAJA_ASSERT(not solution_checker.check_state_and_abstraction(*current, path.get_pa_target_state())) // Since we always add target to predicate set.

        /* Final concrete state is not actually unsafe -> spurious; refine on the violated reach atoms. */
        result->set_spurious(SpuriousnessResult::Target);
        SpuriousnessChecker::add_relevant_pred_split(*result, *reach, *current);
        return result;

    }

    /* All checks passed: this is a genuine (transition-feasible) unsafe concretization. */
    PLAJA_ASSERT(not result->is_spurious())
    return result;

}

/*
 * Policy-aware spuriousness check.
 *
 * Counterpart to check_path() above: check_path() verifies that an abstract unsafe path is
 * concretizable as a plain MDP trajectory (abstract-state membership, non-terminality, guard
 * applicability, transition relation, final target/reach condition). This routine adds the one
 * thing check_path() does not: it verifies that the *policy* (the NN, or a tree ensemble under
 * USE_VERITAS) actually selects the assumed action at every step.
 *
 * It is called on a path already known to be transition-feasible, so the structural checks here
 * are PLAJA_ASSERTs (assumed true). The only check that can newly fail is the policy *selection*
 * check. If it fails, the abstract path is impossible under the policy => spurious, and we add
 * refinement predicates that split the offending abstract state so this fake path cannot recur.
 * If the whole path survives, we have found a genuine policy-induced unsafe trajectory (a real
 * counterexample), and a non-spurious result is returned.
 */
std::unique_ptr<SpuriousnessResult> SpuriousnessChecker::check_path_nn(std::unique_ptr<SolutionCheckerInstancePaPath>&& path_instance) const {
    STMT_IF_DEBUG(constexpr bool debug_log = true;)
    PLAJA_LOG_DEBUG_IF(debug_log, "Checking path concretization (nn aware) ...")
    // PLAJA_ASSERT(pathExistenceChecker->has_nn())

    const auto& solution_checker = path_instance->get_checker_pa();   // Evaluates guards/updates/abstraction/policy.
    const auto& path = path_instance->get_path();                     // The abstract path under test.

    /* Sanity: concrete seed at step 0, sizes/targets line up; here policy target == path target. */
    PLAJA_ASSERT(path_instance->get_solution(0))
    PLAJA_ASSERT(path_instance->get_solution_size() == path.get_state_path_size())
    PLAJA_ASSERT(path_instance->get_target_step() == path.get_state_path_size() - 1)
    PLAJA_ASSERT(path_instance->get_policy_target_step() == path_instance->get_target_step())
    PLAJA_ASSERT(path_instance->is_pa_state_aware() == paStateAware) // For convenience.

    const auto* current = path_instance->get_solution(0);            // Concrete state we are tracing forward.
    const StateValues* successor; // NOLINT(*-init-variables)

    /* Seed state must lie in the source abstract state (already established by check_path). */
    PLAJA_ASSERT(solution_checker.check_state_and_abstraction(*current, path.get_pa_source_state()));

    /* Result accumulator; takes ownership of the path instance (successors are already cached in it). */
    auto* path_instance_ptr = path_instance.get();
    std::unique_ptr<SpuriousnessResult> result(new SpuriousnessResult(*predicates, std::move(path_instance)));

    /* Walk each step, this time also checking the policy selection. */
    for (auto path_it = path.init_path_iterator(); !path_it.end(); ++path_it) {
        PLAJA_LOG_DEBUG_IF(debug_log, "Path Step.")

        /* Tag refinement predicates with the current step index. */
        result->set_prefix_length(path_it.get_step());

        const auto& action_op = solution_checker.get_action_op(path_it.get_op_id()); // Operator assumed at this step.

        /* Structural checks already guaranteed by the prior check_path() pass -> assert only. */
        PLAJA_ASSERT(not paStateAware or solution_checker.check_state_and_abstraction(*current, path_it.get_pa_state())) // Abstract-state membership.
        PLAJA_ASSERT(not solution_checker.check_terminal(*current));                                                    // Non-terminality.
        PLAJA_ASSERT(solution_checker.check_applicability(*current, action_op, nullptr));                               // Guard applicability.

        /* THE policy-selection check (the new work in this routine). */
        /* The witness is a concrete state where the policy DOES select this action (proof the abstract
         * edge is selectable); assert that invariant holds. Note: the witness is NOT the violation. */
        PLAJA_ASSERT(not path_it.has_witness() or solution_checker.check_policy(*path_it.get_witness(), action_op._action_label(), nullptr)) // Witness should be selected.
        if (not solution_checker.check_policy(*current, action_op._action_label(), nullptr)) {
            /* The policy does NOT pick this action at the concrete state we actually reached.
             * So the abstract step is feasible only because the abstraction merged `current` (other
             * action) with the witness (this action). That conflation is the spuriousness. */
            /* TODO alternatives: concretization not in (over-approximation) of NN input space for action label / not in predicate state. */
            /* Action is not selected -> for now add (over-approximating) selection condition. */
            result->set_spurious(SpuriousnessResult::ActionSel);

            /* Hand the violation to the refiner, which synthesizes predicates separating the witness
             * (action selected) from `current` (action not selected). The witness comes in two flavors
             * depending on the policy representation: an interval/box (tree ensemble) or a point (NN). */
            #ifdef USE_VERITAS
            if (selectionRefinement->needs_interval_witness()) {
                /* Box-based refinement (Veritas ensemble): fetch the recorded interval witness. */
                auto box = path_it.get_box_witness();
                if (box.empty()) {
                    /* No box recorded -> fall back to the point witness as a degenerate (collapsed) box.
                     * The witness may be absent (id == STATE::none): tolerated downstream by
                     * add_refinement_preds (non-ws fallback), so only build the box if it exists. */
                    if (const auto witness_state = path_it.get_witness()) {
                        box = witness_state->to_state_values().get_box();
                    }
                }
                // PLACEHOLDER FOR WITNESS REFINEMENT
                /* Refine using: result sink, the action, the witness box, and the violating concrete state. */
                selectionRefinement->add_refinement_preds(*result, action_op._action_label(), box, current);
            } else {
                /* Point-based refinement: dump witness/current for debugging, then refine on the point witness. */
                const auto witness_state = path_it.get_witness(); // Materialize once; reused for the dumps and the refinement call below. May be null (no witness recorded, id == STATE::none).
                if (witness_state) { std::cout << "Concrete witness:"; witness_state->to_state_values().dump(); }
                else { std::cout << "Concrete witness: <none recorded>" << std::endl; }
                std::cout << "Current state with unselected action:"; current->dump();

                /* Dump the abstract (predicate) state and, for each predicate, how the witness and the
                 * current state evaluate it. Membership (is_abstraction) only constrains predicates the
                 * abstract state has SET; under lazy PA, unset predicates are unconstrained, so the
                 * witness and current MAY legitimately differ on them (benign). The real bug is only a
                 * predicate the abstract state has SET to a definite value that the witness or current
                 * does NOT match -- that means it is not actually a member of this abstract state. */
                // const auto& pa_state = path_it.get_pa_state();
                /* Identity line: cross-reference with [WITNESS-RETRIEVE] (witness id + source id + #preds).
                 * If WITNESS-BUG never fires upstream but the witness violates SET predicates here, then
                 * this pa_state (id/#preds) will NOT match the source the witness was retrieved against. */
                // std::cout << "[WITNESS-CHECK] step " << path_it.get_step()
                //           << ": witness id " << path_it.get_witness_id()
                //           << ", pa_state (id " << pa_state.get_id_value() << ", #preds " << pa_state.get_size_predicates()
                //           << "), pa_state.is_abstraction(witness)=" << pa_state.is_abstraction(*witness_state)
                //           << ", pa_state.is_abstraction(current)=" << pa_state.is_abstraction(*current) << std::endl;
                // std::cout << "Predicate state (idx: abstract | witness | current):" << std::endl;
                // for (auto pred_it = pa_state.init_pred_state_iterator(); !pred_it.end(); ++pred_it) {
                //     const auto& predicate = pred_it.predicate();
                //     const bool is_set = pred_it.is_set();
                //     const auto witness_val = predicate.evaluate_integer(*witness_state);
                //     const auto current_val = predicate.evaluate_integer(*current);
                //     const std::string abstract_val = is_set ? std::to_string(pred_it.predicate_value()) : std::string("unset");

                //     std::string flag;
                //     if (is_set) {
                //         /* Membership violations on a set predicate are the actual bug. */
                //         if (witness_val != pred_it.predicate_value()) { flag += "   <-- WITNESS violates SET predicate (not in abstract state!)"; }
                //         if (current_val != pred_it.predicate_value()) { flag += "   <-- CURRENT violates SET predicate (not in abstract state!)"; }
                //     } else if (witness_val != current_val) {
                //         /* Differ only on an unset predicate -> expected under lazy PA, not a bug. */
                //         flag += "   (differ on UNSET predicate; benign under lazy PA)";
                //     }

                //     std::cout << "  [" << pred_it.predicate_index() << "] " << abstract_val
                //               << " | " << witness_val << " | " << current_val << flag << "  :  ";
                //     predicate.dump();
                // }

                selectionRefinement->add_refinement_preds(*result, action_op._action_label(), witness_state.get(), current);
            }
            #else
                /* Non-Veritas build (NN policy): point-witness refinement only. */
                selectionRefinement->add_refinement_preds(*result, action_op._action_label(), path_it.get_witness().get(), current);
            #endif
            return result;
        }
        PLAJA_LOG_DEBUG_IF(debug_log, "Policy selection good.")

        /* Successor was already computed during the prior check_path() pass -> just retrieve it. */
        PLAJA_ASSERT(path_instance_ptr->get_solution(path_it.get_successor_step()))
        successor = path_instance_ptr->get_solution(path_it.get_successor_step());
        PLAJA_ASSERT(solution_checker.agrees(*current, action_op, path_it.get_update_index(), *successor))

        /* Advance the prefix tag and step forward. */
        result->set_prefix_length(path_it.get_step() + 1);

        current = successor;
    }

    /* End-of-path invariants (all already guaranteed; assert only): target membership, ... */
    PLAJA_ASSERT(not paStateAware or solution_checker.check_state_and_abstraction(*current, path.get_pa_target_state()))

    /* ... non-terminality of the final state, ... */
    PLAJA_ASSERT(not solution_checker.check_terminal(*current));

    /* ... and that the final state truly satisfies the unsafe reach condition. */
    STMT_IF_DEBUG(const auto* reach = pathExistenceChecker->get_reach();)
    PLAJA_ASSERT(reach)
    PLAJA_ASSERT(reach->evaluate_integer(*current))

    /* Survived every step under the policy: a real policy-induced unsafe trajectory was found. */
    PLAJA_ASSERT(not result->is_spurious())
    return result;

}

/*
 * Public entry point: decide whether a given abstract unsafe path is spurious, and if so produce
 * refinement predicates. Orchestrates the lower-level checks in two phases:
 *
 *   1. Cheap concrete try from the model's actual initial state (if it lies in the source abstract
 *      state): run check_path() (transition feasibility) and, if it survives, check_path_nn()
 *      (policy feasibility). A surviving path is a real counterexample. Non-determinism may require
 *      escalating to an incremental SMT check for completeness.
 *   2. Otherwise / additionally, check against the symbolic start *condition* via incremental SMT,
 *      then optionally a policy-aware SMT pass.
 *
 * Returns a SpuriousnessResult: spurious (with refinement predicates) or a found concretization.
 */
std::unique_ptr<SpuriousnessResult> SpuriousnessChecker::check_path(const AbstractPath& path) const {
    encounteredNonDetUpdate = false; // Reset per-path; set if any update along the path is non-deterministic.

    PLAJA_ASSERT(pathExistenceChecker->check_start(path.get_pa_source_state(), true))

    /* ---- Phase 1: try the model's concrete initial state, if it belongs to the source abstract state. ---- */
    const auto& initial_state = pathExistenceChecker->get_solution_checker().get_models_initial_values();
    std::unique_ptr<SpuriousnessResult> result_initial_state;
    if (path.get_pa_source_state().is_abstraction(initial_state)) {
        PLAJA_LOG("Checking spuriousness with respect to model's initial state ...")
        /* The concrete init state lies in the source abstract state -> we have a free concrete seed, so
         * use the DETERMINISTIC replay (check_path / check_path_nn) rather than an SMT solve. This is the
         * ONLY place the deterministic check_path() runs; it is skipped entirely when the init state is
         * not a member of the source abstract state (then control falls through to Phase 2 SMT). */
        std::cout << "[DISPATCH] Phase 1: init state IS in source abstract state -> DETERMINISTIC check_path()." << std::endl;

        /* Standard (transition) spuriousness, seeded with the concrete initial state at step 0. */
        auto instance = std::make_unique<SolutionCheckerInstancePaPath>(pathExistenceChecker->get_solution_checker(), path, path.get_target_step(), 0, paStateAware, nullptr, true, pathExistenceChecker->get_reach());
        instance->set_solution(std::make_unique<StateValues>(initial_state), 0);
        result_initial_state = check_path(std::move(instance));

        const bool pa_spurious = result_initial_state->is_spurious(); // Did the plain transition check already fail?
        std::cout << "[DISPATCH] Phase 1: deterministic check_path() -> "
                  << (pa_spurious ? "SPURIOUS (transition infeasible)" : "transition-feasible") << "." << std::endl;

        /* If transition-feasible, additionally check policy feasibility (reusing the cached successors). */
        if (not pa_spurious) {
            std::cout << "[DISPATCH] Phase 1: transition-feasible -> DETERMINISTIC policy check check_path_nn()." << std::endl;
            instance = result_initial_state->retrieve_path_instance();
            instance->set_policy_target(path.get_target_step());
            result_initial_state = check_path_nn(std::move(instance));
        }

        if (not result_initial_state->is_spurious()) {
            std::cout << "[DISPATCH] Phase 1: non-spurious -> REAL counterexample (deterministic concretization)." << std::endl;
            return result_initial_state; // Found concretization.
        }

        /* Further case distinction necessary ... */

        const auto* start = pathExistenceChecker->get_start(); // Symbolic start condition (may be null).

        /* Non-deterministic updates make the single deterministic trace incomplete -> escalate to SMT. */
        if (encounteredNonDetUpdate) { // Must use SMT-check, but only if initial state is not subsumed by start state anyway.
            /* The deterministic trace followed ONE update arm; a non-det update means other concrete
             * traces exist that it never explored, so its result is not conclusive -> redo with SMT. */
            std::cout << "[DISPATCH] Phase 1: non-deterministic update encountered -> deterministic trace incomplete, escalating to SMT." << std::endl;

            /* Skip if the start condition already covers the initial state (handled in phase 2 below). */
            if (not start or not start->evaluate_integer(initial_state)) {

                /* If the plain check was the one that failed, redo it as a full incremental SMT check. */
                if (pa_spurious) {
                    std::cout << "[DISPATCH] Phase 1->SMT: redoing transition check via check_incrementally() (SMT)." << std::endl;
                    result_initial_state = pathExistenceChecker->check_incrementally(std::make_unique<SolutionCheckerInstancePaPath>(pathExistenceChecker->get_solution_checker(), path, path.get_target_step(), 0, paStateAware, nullptr, true, pathExistenceChecker->get_reach()));
                }

                /* If now transition-feasible and a policy is present, also do a policy-aware SMT pass. */
                if (not result_initial_state->is_spurious() and pathExistenceChecker->has_nn()) {

                    PLAJA_ASSERT(result_initial_state->get_path_instance().check())

                    std::cout << "[DISPATCH] Phase 1->SMT: transition-feasible -> SMT policy check check_policy_incrementally()." << std::endl;
                    instance = result_initial_state->retrieve_path_instance();
                    instance->set_policy_target(path.get_target_step());
                    result_initial_state = pathExistenceChecker->check_policy_incrementally(std::move(instance), *selectionRefinement);

                }

            }

        }

        /* No symbolic start condition, or the source state doesn't meet it -> initial-state result is final. */
        if (not start or not pathExistenceChecker->check_start(path.get_pa_source_state(), false)) {
            std::cout << "[DISPATCH] Phase 1: no symbolic start condition (or source state doesn't meet it) -> returning Phase 1 result." << std::endl;
            return result_initial_state;
        }
        std::cout << "[DISPATCH] Phase 1 result not final (symbolic start condition also covers source state) -> falling through to Phase 2." << std::endl;

    } else {
        /* No free concrete seed in the source abstract state -> the deterministic check_path() is
         * inapplicable and skipped; we must let SMT find a concrete start (Phase 2). */
        std::cout << "[DISPATCH] Phase 1 SKIPPED: init state NOT in source abstract state -> no concrete seed for deterministic check_path()." << std::endl;
    }

    /* ---- Phase 2: check against the symbolic start condition via incremental SMT. ---- */
    PLAJA_LOG("Checking spuriousness with respect to start condition ...")
    /* No usable concrete seed -> transition feasibility is decided by SMT (check_incrementally), NOT by
     * the deterministic check_path(). This is why check_path() is not used on every CEGAR iteration. */
    std::cout << "[DISPATCH] Phase 2: SMT transition check via check_incrementally() (deterministic check_path() not used here)." << std::endl;

    PLAJA_ASSERT(pathExistenceChecker->get_start())
    PLAJA_ASSERT(pathExistenceChecker->check_start(path.get_pa_source_state(), false))

    /* Incremental SMT feasibility of the path under the start condition (no policy yet). */
    auto result = pathExistenceChecker->check_incrementally(std::make_unique<SolutionCheckerInstancePaPath>(pathExistenceChecker->get_solution_checker(), path, path.get_target_step(), 0, paStateAware, pathExistenceChecker->get_start(), false, pathExistenceChecker->get_reach()));
    /* Stop here if it's already spurious, or there's no policy (NN/ensemble) to additionally account for. */
    #ifdef USE_VERITAS
    if (result->is_spurious() or not (pathExistenceChecker->has_nn() or pathExistenceChecker->has_ensemble())) {
        std::cout << "[DISPATCH] Phase 2: " << (result->is_spurious() ? "SPURIOUS (transition)" : "no policy to check") << " -> returning SMT result." << std::endl;
        return result;
    }
    #else
    if (result->is_spurious() or not (pathExistenceChecker->has_nn())) {
        std::cout << "[DISPATCH] Phase 2: " << (result->is_spurious() ? "SPURIOUS (transition)" : "no policy to check") << " -> returning SMT result." << std::endl;
        return result;
    }
    #endif
    else {

        // TODO alternatives

        /* Transition-feasible and a policy exists -> still need to account for policy selection. */
        if (checkPolicySpuriousness or encounteredNonDetUpdate) {
            /* Full SMT policy check: requested explicitly, or forced because a non-det update makes the
             * single deterministic policy trace incomplete. */
            std::cout << "[DISPATCH] Phase 2: transition-feasible -> SMT policy check check_policy_incrementally() ("
                      << (checkPolicySpuriousness ? "checkPolicySpuriousness" : "forced by non-det update") << ")." << std::endl;

            /* When encountering non-det. updates, we need SMT_check for completeness. */
            STMT_IF_DEBUG(bool print(true);)
            PLAJA_LOG_DEBUG_IF(not checkPolicySpuriousness and print, PLAJA_UTILS::to_red_string("Warning: Checking policy spuriousness due to non-deterministic update."))
            STMT_IF_DEBUG(print = false;)

            PLAJA_LOG("Checking policy spuriousness ...")

            /* Full policy-aware incremental SMT check; refines w.r.t. the longest policy concretization. */
            auto instance = result->retrieve_path_instance();
            instance->set_policy_target(path.get_target_step());
            auto result_policy = pathExistenceChecker->check_policy_incrementally(std::move(instance), *selectionRefinement);
            PLAJA_LOG_IF(result_policy->is_spurious(), "Spurious under policy.")

            return result_policy;

        } else {

            /* Cheaper alternative: sample a concrete source state from the SMT model and run the
             * deterministic policy check check_path_nn() on it, refining on its violation. */
            std::cout << "[DISPATCH] Phase 2: transition-feasible -> sampling SMT model, DETERMINISTIC policy check check_path_nn() (cheaper alternative)." << std::endl;

            auto instance = result->retrieve_path_instance();
            PLAJA_ASSERT(instance)
            PLAJA_ASSERT(not instance->is_invalidated())
            instance->set_policy_target(path.get_target_step());
            return check_path_nn(std::move(instance));

        }

        /* (option) Compute WP of (over-approximating) selection condition on path (prefix). */

        /* (naive option) Enumerate all standard PA path start states (and refine). */

    }
}
