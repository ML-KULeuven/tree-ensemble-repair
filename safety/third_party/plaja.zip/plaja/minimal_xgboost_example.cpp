#include <xgboost/c_api.h>
#include <cmath>
#include <iostream>
#include <vector>

// Installing xgboost:
// git clone --recursive https://github.com/dmlc/xgboost
// cd xgboost
// mkdir build
// cd build
// cmake .. -DCMAKE_INSTALL_PREFIX=../install
// make -j4
// make install

// Inside example experiments
// export LD_LIBRARY_PATH=../dependencies/xgboost/lib:$LD_LIBRARY_PATH
// g++ main.cpp -o main_xgboost_test     -I ../dependencies/xgboost/include     -L ../dependencies/xgboost/lib -lxgboost -Wl,-rpath,../dependencies/xgboost/lib
// ./main_xgboost_test

int main() {
    // -----------------------------
    // 1️⃣ Synthetic XOR dataset
    std::cout << "Creating dataset..." << std::endl;
    
    // 8 rows, 2 features
    std::vector<float> data = {
        1,1, 1,1, 1,1, 1,1,  // first 4 rows
        0,0, 0,1, 1,0, 1,1   // next 4 rows (duplicate)
    };
    std::vector<float> labels = {1,1,1,1,0,1,1,0};  // 8 labels

    // Print the data to verify
    std::cout << "Data (8 rows, 2 columns):" << std::endl;
    for (int i = 0; i < 8; i++) {
        std::cout << "Row " << i << ": [" 
                  << data[i*2] << ", " << data[i*2+1] 
                  << "] -> label: " << labels[i] << std::endl;
    }

    // -----------------------------
    // 2️⃣ Create DMatrix
    std::cout << "\nCreating DMatrix..." << std::endl;
    
    DMatrixHandle dtrain;
    // Note: XGDMatrixCreateFromMat expects data in row-major order, which we have
    int ret = XGDMatrixCreateFromMat(data.data(), 8, 2, -1.0f, &dtrain);
    if (ret != 0) {
        std::cerr << "Failed to create DMatrix: " << XGBGetLastError() << std::endl;
        return 1;
    }
    
    // Set labels
    ret = XGDMatrixSetFloatInfo(dtrain, "label", labels.data(), 8);
    if (ret != 0) {
        std::cerr << "Failed to set labels: " << XGBGetLastError() << std::endl;
        return 1;
    }
    
    // Verify labels were set correctly
    bst_ulong out_len;
    const float* out_labels;
    ret = XGDMatrixGetFloatInfo(dtrain, "label", &out_len, &out_labels);
    if (ret == 0) {
        std::cout << "Labels in DMatrix: ";
        for (bst_ulong i = 0; i < out_len; i++) {
            std::cout << out_labels[i] << " ";
        }
        std::cout << std::endl;
    }

    // -----------------------------
    // 3️⃣ Create booster
    std::cout << "\nCreating booster..." << std::endl;
    
    BoosterHandle booster;
    ret = XGBoosterCreate(&dtrain, 1, &booster);
    if (ret != 0) {
        std::cerr << "Failed to create booster: " << XGBGetLastError() << std::endl;
        return 1;
    }

    // -----------------------------
    // 4️⃣ Set parameters - try a simpler configuration first
    std::cout << "Setting parameters..." << std::endl;
    
    XGBoosterSetParam(booster, "booster", "gbtree");
    XGBoosterSetParam(booster, "max_depth", "3");
    XGBoosterSetParam(booster, "eta", "0.3");
    XGBoosterSetParam(booster, "objective", "binary:logistic");
    XGBoosterSetParam(booster, "tree_method", "approx");  // 'hist' is more robust for small data
    XGBoosterSetParam(booster, "eval_metric", "logloss");
    XGBoosterSetParam(booster, "seed", "42");
    
    // Disable some features that might cause issues
    XGBoosterSetParam(booster, "subsample", "1.0");
    XGBoosterSetParam(booster, "colsample_bytree", "1.0");
    XGBoosterSetParam(booster, "min_child_weight", "0");
    
    // -----------------------------
    // 5️⃣ Train and evaluate
    std::cout << "\nStarting training..." << std::endl;
    
    for (int iter = 0; iter < 20; ++iter) {
        // Update one iteration
        ret = XGBoosterUpdateOneIter(booster, iter, dtrain);
        if (ret != 0) {
            std::cerr << "Training failed at iteration " << iter
                      << ": " << XGBGetLastError() << std::endl;
            return 1;
        }
        
        // Get evaluation result
        const char* eval_names[1] = {"train"};
        DMatrixHandle eval_mats[1] = {dtrain};
        const char* eval_result;
        ret = XGBoosterEvalOneIter(booster, iter, eval_mats, eval_names, 1, &eval_result);
        if (ret == 0) {
            std::cout << eval_result << std::endl;
        }

        // Predict on training data
        bst_ulong pred_len;
        const float* pred_result;
        // Use option 0 for normal prediction
        ret = XGBoosterPredict(booster, dtrain, 0, 0, 0, &pred_len, &pred_result);
        if (ret != 0) {
            std::cerr << "Prediction failed: " << XGBGetLastError() << std::endl;
            continue;
        }

        // Print predictions every 5 iterations
        if (iter % 5 == 0 || iter == 19) {
            std::cout << "Iteration " << iter << " predictions: ";
            for (bst_ulong i = 0; i < pred_len; ++i) {
                printf("%.3f ", pred_result[i]);
            }
            
            // Convert to binary
            std::cout << "→ classified: ";
            for (bst_ulong i = 0; i < pred_len; ++i) {
                std::cout << (pred_result[i] > 0.5 ? 1 : 0) << " ";
            }
            std::cout << std::endl;
            
            // Calculate accuracy
            int correct = 0;
            for (bst_ulong i = 0; i < pred_len; i++) {
                if ((pred_result[i] > 0.5) == (labels[i] > 0.5)) {
                    correct++;
                }
            }
            std::cout << "  Accuracy: " << correct << "/" << pred_len 
                      << " (" << (100.0f * correct / pred_len) << "%)" << std::endl;
        }
    }

    // -----------------------------
    // 6️⃣ Cleanup
    XGBoosterFree(booster);
    XGDMatrixFree(dtrain);

    return 0;
}